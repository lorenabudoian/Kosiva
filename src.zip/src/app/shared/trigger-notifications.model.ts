export class NotificationsModel {
    constructor(public type: string, public message: string){}
}