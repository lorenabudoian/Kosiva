export class Card {
    constructor(
      public cardholder: string, 
      public cardnumber: number, 
      public cardcode: number, 
      public cardyear: number,
      public cardmonth: number,
      public cardtype: string,
    ){}
  }
  