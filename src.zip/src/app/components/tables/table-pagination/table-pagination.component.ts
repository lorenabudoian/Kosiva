import {
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import {
  MatPaginator
} from '@angular/material/paginator';
import {
  MatTableDataSource
} from '@angular/material/table';

export interface Transaction {
  clientName: string;
  clientJob: string;
  cost: number;
  orderId: number;
  profit: number;
  city: string;
  status: string;
}

const transactions: Transaction[] = [{
  clientName: 'Herriet Lorent',
  orderId: 924,
  clientJob: 'HR Manager',
  cost: 3,
  profit: 18,
  city: 'Malindi',
  status: 'Confirmed'
},
{
  clientName: 'Victor Arnold',
  orderId: 192,
  clientJob: 'Human Resources Manager',
  cost: 26,
  profit: 3,
  city: 'Kibwezi',
  status: 'Pending'
},
{
  clientName: 'Golden Rossen',
  orderId: 132,
  clientJob: 'HR Business Partner',
  cost: 296,
  profit: 5,
  city: 'Litein',
  status: 'Confirmed'
},
{
  clientName: 'Victor Samuel',
  orderId: 772,
  clientJob: 'Tech Talents Recruiter',
  cost: 4,
  profit: 2,
  city: 'San Salvador',
  status: 'Pending'
},
{
  clientName: 'Harriet Scott',
  orderId: 612,
  clientJob: 'Talent Partner',
  cost: 5,
  profit: 10,
  city: 'Santa Ana',
  status: 'Pending'

},
{
  clientName: 'Golden Rossen',
  orderId: 236,
  clientJob: 'IT Recruiter at CGS',
  cost: 24,
  profit: 3,
  city: 'Delmas',
  status: 'Pending'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  status: 'Confirmed'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  status: 'Confirmed'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  status: 'Confirmed'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  status: 'Confirmed'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  status: 'Confirmed'

},
];


@Component({
  selector: 'app-table-pagination',
  templateUrl: './table-pagination.component.html',
  styleUrls: ['./table-pagination.component.scss']
})

export class TablePaginationComponent implements OnInit {



  ngOnInit() {
      this.dataSource.paginator = this.paginator;
  }




  @ViewChild(MatPaginator, {
      static: true
  }) paginator: MatPaginator;
  dataSource = new MatTableDataSource < Transaction > (transactions);


  displayedColumns: string[] = ['position', 'clientName', 'cost', 'city', 'orderId', 'status', 'profit', 'save'];

  constructor() {}



}