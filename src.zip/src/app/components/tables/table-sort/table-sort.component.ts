import {
  Component,
  OnInit,
  ViewChild
} from '@angular/core';
import {
  MatPaginator
} from '@angular/material/paginator';
import {
  MatSort
} from '@angular/material/sort';
import {
  MatTableDataSource
} from '@angular/material/table';

export interface Transaction {
  clientName: string;
  clientJob: string;
  cost: number;
  orderId: number;
  profit: number;
  city: string;
  progressValue: number;
  colorBar: string;
}

const transactions: Transaction[] = [{
  clientName: 'Herriet Lorent',
  orderId: 924,
  clientJob: 'HR Manager',
  cost: 3,
  profit: 18,
  city: 'Malindi',
  progressValue: 40,
  colorBar: 'primary'

},
{
  clientName: 'Victor Arnold',
  orderId: 192,
  clientJob: 'Human Resources Manager',
  cost: 26,
  profit: 3,
  city: 'Kibwezi',
  progressValue: 20,
  colorBar: 'accent'

},
{
  clientName: 'Golden Rossen',
  orderId: 132,
  clientJob: 'HR Business Partner',
  cost: 296,
  profit: 5,
  city: 'Litein',
  progressValue: 80,
  colorBar: 'warn'

},
{
  clientName: 'Victor Samuel',
  orderId: 772,
  clientJob: 'Tech Talents Recruiter',
  cost: 4,
  profit: 2,
  city: 'San Salvador',
  progressValue: 70,
  colorBar: 'accent'

},
{
  clientName: 'Harriet Scott',
  orderId: 612,
  clientJob: 'Talent Partner',
  cost: 5,
  profit: 10,
  city: 'Santa Ana',
  progressValue: 95,
  colorBar: 'primary'

},
{
  clientName: 'Golden Rossen',
  orderId: 236,
  clientJob: 'IT Recruiter at CGS',
  cost: 24,
  profit: 3,
  city: 'Delmas',
  progressValue: 36,
  colorBar: 'warn'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  progressValue: 40,
  colorBar: 'accent'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  progressValue: 86,
  colorBar: 'primary'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  progressValue: 93,
  colorBar: 'accent'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  progressValue: 50,
  colorBar: 'primary'

},
{
  clientName: 'Earl  Hopkins',
  orderId: 4162,
  clientJob: 'Finance Analyst',
  cost: 5,
  profit: 370,
  city: 'Gonaïves',
  progressValue: 74,
  colorBar: 'primary'
},
];


@Component({
  selector: 'app-table-sort',
  templateUrl: './table-sort.component.html',
  styleUrls: ['./table-sort.component.scss']
})
export class TableSortComponent implements OnInit {

  constructor() {}

  ngOnInit() {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
  }

 
  displayedColumns: string[] = ['position', 'clientName', 'orderId', 'cost', 'city', 'profit', 'progressBar', 'download'];

  @ViewChild(MatPaginator, {
      static: true
  }) paginator: MatPaginator;
  @ViewChild(MatSort, {
    static: true
   }) sort: MatSort;
  dataSource = new MatTableDataSource < Transaction > (transactions);





}