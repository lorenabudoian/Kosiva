import {
  Component
} from '@angular/core';
import {
  MatTableDataSource
} from '@angular/material/table';

export interface Transaction {
  clientName: string;
  clientJob: string;
  cost: number;
  orderId: number;
  profit: number;
  city: string;
  status: string;
  level: string;
}


const transactions: Transaction[] = [{
      clientName: 'Herriet Lorent',
      orderId: 924,
      clientJob: 'HR Manager',
      cost: 3,
      profit: 18,
      city: 'Malindi',
      status: 'Confirmed',
      level: 'Low'
  },
  {
      clientName: 'Victor Arnold',
      orderId: 192,
      clientJob: 'Human Resources Manager',
      cost: 26,
      profit: 3,
      city: 'Kibwezi',
      status: 'Pending',
      level: 'Hight'
  },
  {
      clientName: 'Golden Rossen',
      orderId: 132,
      clientJob: 'HR Business Partner',
      cost: 296,
      profit: 5,
      city: 'Litein',
      status: 'Confirmed',
      level: 'Low'
  },
  {
      clientName: 'Victor Samuel',
      orderId: 772,
      clientJob: 'Tech Talents Recruiter',
      cost: 4,
      profit: 2,
      city: 'San Salvador',
      status: 'Pending',
      level: 'Hight'

  },
  {
      clientName: 'Harriet Scott',
      orderId: 612,
      clientJob: 'Talent Partner',
      cost: 5,
      profit: 10,
      city: 'Santa Ana',
      status: 'Pending',
      level: 'Medium'
  }
];

@Component({
  selector: 'app-filter-table',
  templateUrl: './filter-table.component.html',
  styleUrls: ['./filter-table.component.scss']
})
export class FilterTableComponent {

 
  displayedColumns: string[] = ['position', 'clientName', 'cost', 'city', 'level', 'orderId', 'profit', ];
  dataSource = new MatTableDataSource < Transaction > (transactions);

  applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}