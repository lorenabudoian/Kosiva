import { Component, AfterViewInit, OnInit, OnDestroy} from '@angular/core';
import { AppProviderService } from '../../../services/appprovider.service';

@Component({
  selector: 'app-error-page-style-one',
  templateUrl: './error-page-style-one.component.html',
  styleUrls: ['./error-page-style-one.component.scss']
})
export class ErrorPageStyleOneComponent implements OnInit, OnDestroy{

  constructor( public service: AppProviderService) { 
    this.service.setPageType('404');
  }

  ngOnInit(): void {
  }

  ngOnDestroy() {
    this.service.setPageType(null);
  }

}
