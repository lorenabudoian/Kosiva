import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppProviderService } from '../../../services/appprovider.service';

@Component({
  selector: 'app-error-page-style-two',
  templateUrl: './error-page-style-two.component.html',
  styleUrls: ['./error-page-style-two.component.scss']
})
export class ErrorPageStyleTwoComponent implements OnInit, OnDestroy {

  constructor( public service: AppProviderService ) { 
    this.service.setPageType('404');
  }

  ngOnInit(): void {
  }

  ngOnDestroy(){
    this.service.setPageType(null);
  }

}
