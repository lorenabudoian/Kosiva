import { Component, OnInit, Inject }from '@angular/core';
import { NgForm } from '@angular/forms';
import { Card } from '../../../shared/card.model';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CardService } from '../../../services/card.service';
import { FormGroup, FormBuilder, Validators , FormControl} from '@angular/forms';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.scss'],
  providers: [{
    provide: MatDialogRef,
    useValue: {}
  }, {
    provide: MAT_DIALOG_DATA,
    useValue: {}
  }]
})
export class CardsComponent implements OnInit{

  hide = false;  

  displayedColumns: string[] = ['position', 'cardNumber', 'cardHolder', 'cardmonth', 'download', 'removeItem'];

  cards: Card[];


  deleteItem(index: number) {
      var confirmDelete = confirm('Do you want to continue ?');

      if (confirmDelete) {
          const transaction = this.cards.filter((transaction, tIndex) => {
              return index !== tIndex
          });
          this.cards = transaction;
      } else {
          return false;
      }
  }

  public openDialog(data) {
      const dialogRefcard = this.interactivedialog.open(AddCardComponent, {
          data: data
      });
  }

  constructor(
    public interactivedialog: MatDialog, 
    private cardService: CardService
  ) {}


  ngOnInit() {
    this.cards = this.cardService.getCards();
    this.cardService.AddCard
    .subscribe(
      (cards: Card[]) => {
        this.cards = cards;
      }
    )
  }

  ngOnDestroy() {
    this.cardService.AddCard.unsubscribe();
  }
}

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./cards.component.scss']
})
export class AddCardComponent implements OnInit {
  showSpinner = false;
  form: FormGroup;
  addedCardvalue:any;

  cards:any = ["Visa Card","Master Card"];
  years:any = ["2020","2021","2022","2023","2024","2025","2026","2027","2028","2029","2030"];
  months:any = ["01","02","03","04","05","06","07","08","09","10","11","12"];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, 
    private cardService: CardService,
    private formBuilder: FormBuilder
  ) { this.createForm(); };

  onSubmit(formData: NgForm) {

      this.showSpinner = true;
      this.addedCardvalue = this.form.value;
      const addedCard = new Card(
        this.addedCardvalue.cardholder,
        this.addedCardvalue.cardnumber.substr(this.addedCardvalue.cardnumber.length - 4), 
        this.addedCardvalue.cardcode, 
        this.addedCardvalue.cardyear, 
        this.addedCardvalue.cardmonth, 
        this.addedCardvalue.cardtype
      );
      this.cardService.addCard(addedCard);
  
  }

  private createForm() {
    this.form = this.formBuilder.group({
      cardholder: [ '', Validators.compose([Validators.required, Validators.pattern('[a-zA-Z ]*')])],
      cardmonth: [ '', Validators.required],
      cardyear: [ '', Validators.required],
      cardcode: [ '', Validators.compose([Validators.required, Validators.minLength(3)])],
      cardnumber: [ '', Validators.compose([Validators.required, Validators.minLength(16)])],
      cardtype: [ '', Validators.required],
    });
  }
  
  ngOnInit() {
  }

}
