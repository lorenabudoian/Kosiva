import { Component, OnInit } from '@angular/core';


export interface Transaction {
  clientName: string;
  date: string;
  clientJob: string;
  amount: number;
  orderId: number;
  status: string;
}


@Component({
  selector: 'app-payment-history',
  templateUrl: './payment-history.component.html',
  styleUrls: ['./payment-history.component.scss']
})
export class PaymentHistoryComponent implements OnInit {

  displayedColumns: string[] = ['date', 'clientName', 'amount', 'status',  'orderId', 'invoice'];

  transactions: Transaction[] = [{
          clientName: 'Herriet Lorent',
          orderId: 924,
          date: '29.04.2020',
          clientJob: 'HR Manager',
          amount: 3,
          status: 'Confirmed'
      },
      {
          clientName: 'Victor Arnold',
          orderId: 192,
          date: '28.04.2020',
          clientJob: 'Human Resources Manager',
          amount: 26,
          status: 'Pending'
      },
      {
          clientName: 'Golden Rossen',
          orderId: 132,
          clientJob: 'HR Business Partner',
          amount: 296,
          date: '27.04.2020',
          status: 'Confirmed'
      },
      {
          clientName: 'Victor Samuel',
          orderId: 772,
          clientJob: 'Tech Talents Recruiter',
          amount: 4,
          date: '27.04.2020',
          status: 'Pending'
      },
      {
          clientName: 'Harriet Scott',
          orderId: 612,
          clientJob: 'Talent Partner',
          amount: 5,
          date: '26.04.2020',
          status: 'Pending'

      },
      {
          clientName: 'Golden Rossen',
          orderId: 236,
          clientJob: 'IT Recruiter at CGS',
          amount: 24,
          date: '25.04.2020',
          status: 'Pending'

      },
      {
          clientName: 'Earl  Hopkins',
          orderId: 4162,
          clientJob: 'Finance Analyst',
          amount: 5,
          date: '25.04.2020',
          status: 'Confirmed'

      },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
