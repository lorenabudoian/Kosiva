import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-my-balance',
  templateUrl: './my-balance.component.html',
  styleUrls: ['./my-balance.component.scss'],
})
export class MyBalanceComponent implements OnInit {

  currencies = [
    { imagePath: "../../../../assets/img/euro.png", currencyName: 'Euro', totalamount: 8.4334, minimamount: 13.344 },
    { imagePath: "../../../../assets/img/pounds.png", currencyName: 'Pounds', totalamount: 80.14, minimamount: 54.344 },
    { imagePath: "../../../../assets/img/dollar.png", currencyName: 'US Dollar', totalamount: 5.24, minimamount: 34.4343 },
    { imagePath: "../../../../assets/img/euro.png", currencyName: 'Euro', totalamount: 8.4334, minimamount: 13.344 },
    { imagePath: "../../../../assets/img/euro.png", currencyName: 'Euro', totalamount: 8.4334, minimamount: 13.344 },
    { imagePath: "../../../../assets/img/pounds.png", currencyName: 'Pounds', totalamount: 80.14, minimamount: 54.344 },
    { imagePath: "../../../../assets/img/pounds.png", currencyName: 'Pounds', totalamount: 80.14, minimamount: 54.344 },
    { imagePath: "../../../../assets/img/pounds.png", currencyName: 'Pounds', totalamount: 80.14, minimamount: 54.344 },
    { imagePath: "../../../../assets/img/indian.png", currencyName: 'Indian Rupees', totalamount: 9.934, minimamount: 19.243 },

  ]

  ngOnInit(): void {
   
  }

}
