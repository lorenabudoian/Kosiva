
import { NotificationsModel } from '../../shared/trigger-notifications.model';