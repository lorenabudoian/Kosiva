import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trigger-notifications',
  templateUrl: './trigger-notifications.component.html',
  styleUrls: ['./trigger-notifications.component.css']
})
export class TriggerNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
