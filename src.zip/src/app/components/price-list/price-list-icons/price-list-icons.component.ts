import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-list-icons',
  templateUrl: './price-list-icons.component.html',
  styleUrls: ['./price-list-icons.component.scss']
})
export class PriceListIconsComponent implements OnInit {

  itemsTextPriceOne =[{
      textPrice: 'Visual Page Builder'
    },
    {
       textPrice: 'Advance theme question'
    },
    {
       textPrice: 'Easy access to funds'
    },
    {
      textPrice: 'Basic donor data'
    },
    {
      textPrice: 'Comprehensive donor data'
    }
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
