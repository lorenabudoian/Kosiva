import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-list-rocket',
  templateUrl: './price-list-rocket.component.html',
  styleUrls: ['./price-list-rocket.component.scss']
})
export class PriceListRocketComponent implements OnInit {


  itemsTextPriceOne =[{
    textPrice: 'Visual Page Builder'
  },
  {
     textPrice: 'Advance theme question'
  },
  {
     textPrice: 'Easy access to funds'
  },
  {
    textPrice: 'Basic donor data'
  },
  {
    textPrice: 'Comprehensive donor data'
  }
]

  constructor() { }

  ngOnInit(): void {
  }

}
