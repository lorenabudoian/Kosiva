import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-style-one',
  templateUrl: './form-style-one.component.html',
  styleUrls: ['./form-style-one.component.scss']
})
export class FormStyleOneComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }
}
