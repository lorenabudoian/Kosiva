import { Component,  ViewChild, ElementRef, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-third-form-layout',
  templateUrl: './third-form-layout.component.html',
  styleUrls: ['./third-form-layout.component.scss']
})

export class ThirdFormLayoutComponent implements AfterViewInit {

  public state: any  = {
    steps: [
      "shipping",
      "billing",
      "payment_confirmation"
    ], 
    counterelements: 0,
    checkout: "shipping",
  };



  changestep( activestep ){
    
    this.state.counterelements = activestep;
    this.state.checkout = this.state.steps[activestep];
    

      if (this.state.checkout === "billing"){

        if(this.state.counterelements ) {
          console.log('false');
          return false;
        }

    }

  }

  constructor() {  
  }

  ngAfterViewInit() {
   
  }

}
