import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-layout',
  templateUrl: './first-layout.component.html',
  styleUrls: ['./first-layout.component.scss']
})
export class FirstLayoutComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {
  }

}
