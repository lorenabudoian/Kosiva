import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-style-two',
  templateUrl: './form-style-two.component.html',
  styleUrls: ['./form-style-two.component.scss']
})
export class FormStyleTwoComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
