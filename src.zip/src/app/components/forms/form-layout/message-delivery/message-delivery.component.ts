import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-delivery',
  templateUrl: './message-delivery.component.html',
  styleUrls: ['./message-delivery.component.scss']
})
export class MessageDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
