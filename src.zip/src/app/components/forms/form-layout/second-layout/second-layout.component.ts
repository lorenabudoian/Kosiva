import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-second-layout',
  templateUrl: './second-layout.component.html',
  styleUrls: ['./second-layout.component.scss']
})
export class SecondLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
