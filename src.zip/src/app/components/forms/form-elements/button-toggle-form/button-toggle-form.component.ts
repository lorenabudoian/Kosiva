import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-button-toggle-form',
  templateUrl: './button-toggle-form.component.html',
  styleUrls: ['./button-toggle-form.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ButtonToggleFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
