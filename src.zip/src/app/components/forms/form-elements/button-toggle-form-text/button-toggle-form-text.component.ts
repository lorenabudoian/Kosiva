import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-toggle-form-text',
  templateUrl: './button-toggle-form-text.component.html',
  styleUrls: ['./button-toggle-form-text.component.scss']
})
export class ButtonToggleFormTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
