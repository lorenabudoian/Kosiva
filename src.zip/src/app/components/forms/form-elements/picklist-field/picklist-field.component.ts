import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';

interface Country {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-picklist-field',
  templateUrl: './picklist-field.component.html',
  styleUrls: ['./picklist-field.component.scss']
})
export class PicklistFieldComponent implements OnInit {

  countries: Country[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];

  toppings = new FormControl();
  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  constructor() { }

  ngOnInit(): void {
  }

}
