import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrapper-second-container',
  templateUrl: './wrapper-second-container.component.html',
  styleUrls: ['./wrapper-second-container.component.scss']
})
export class WrapperSecondContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
