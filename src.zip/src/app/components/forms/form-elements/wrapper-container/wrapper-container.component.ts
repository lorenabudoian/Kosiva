import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrapper-container',
  templateUrl: './wrapper-container.component.html',
  styleUrls: ['./wrapper-container.component.scss']
})
export class WrapperContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
