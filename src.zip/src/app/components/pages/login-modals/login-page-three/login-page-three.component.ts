import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppProviderService } from '../../../../services/appprovider.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page-three',
  templateUrl: './login-page-three.component.html',
  styleUrls: ['./login-page-three.component.scss']
})
export class LoginPageThreeComponent implements OnInit, OnDestroy {

  public username: string;

  constructor(private router: Router, public service: AppProviderService) { 
    this.service.setPageType('login');
  }

  public onLoginClick(){
    this.router.navigate(['./dashboard'])
  }

  ngOnInit(): void {
  }

  ngOnDestroy(){
    this.service.setPageType(null);
  }

}
