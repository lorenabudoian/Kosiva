import { Component, OnInit } from '@angular/core';
import { AppProviderService } from '../../../../services/appprovider.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page-two',
  templateUrl: './login-page-two.component.html',
  styleUrls: ['./login-page-two.component.scss']
})
export class LoginPageTwoComponent implements OnInit {

    
  public username: string;

  constructor(private router: Router, public service: AppProviderService) { 
    this.service.setPageType('login');
  }

  public onLoginClick(){
    this.router.navigate(['./dashboard']);
  }

  ngOnInit(): void {
  }

  ngOnDestroy() {
    this.service.setPageType(null);
  }
}
