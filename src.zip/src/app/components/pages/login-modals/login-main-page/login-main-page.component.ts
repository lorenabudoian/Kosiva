import { Component, OnInit } from '@angular/core';
import { AppProviderService } from '../../../../services/appprovider.service';
import { Router } from '@angular/router';
import { TweenMax }  from "gsap";


@Component({
  selector: 'app-login-main-page',
  templateUrl: './login-main-page.component.html',
  styleUrls: ['./login-main-page.component.scss']
})
export class LoginMainPageComponent implements OnInit {

  public username: string;

  constructor(private router: Router, public service: AppProviderService) { 
    this.service.setPageType('login');
  }

  public onLoginClick(){
    this.router.navigate(['./dashboard']);
  }

  ngOnInit(): void {
    $("#container").mousemove(function(e) {
      parallaxIt(e, ".slide", -90);
      parallaxIt(e, ".circle", -40);

    });
    
    function parallaxIt(e, target, movement) {
      var $this = $("#container");
      var relX = e.pageX - $this.offset().left;
      var relY = e.pageY - $this.offset().top;
    
      TweenMax.to(target, 1, {
        x: (relX - $this.width() / 2) / $this.width() * movement,
        y: (relY - $this.height() / 2) / $this.height() * movement
      });
    }
  }

  ngOnDestroy() {
    this.service.setPageType(null);
  }

}
