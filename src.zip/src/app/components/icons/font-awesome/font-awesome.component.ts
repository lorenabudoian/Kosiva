import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-font-awesome',
  templateUrl: './font-awesome.component.html',
  styleUrls: ['./font-awesome.component.scss']
})
export class FontAwesomeComponent implements OnInit {

  icons: any = [
    { name:"fa-arrow-alt-circle-down", propriety:"Solid:", code:".fas", class:"fa-ic" },
    { name: "fa-ban", propriety:"*Regular:", code:".far", class:"fa-ic" },
    { name:"fa-basketball-ball", propriety:"Size:", code:".fa-lg/2x/3x/4x/5x",  class:"fa-ic" },
    { name:"fa-bell", propriety:"Color:", code:".fa.fa-dark/light", class:" fa-light" },
    { name:"fa-balance-scale", propriety:"Disabled", code:".fa-disabled", class:"fa-disabled fa-ic" },
  ]


  constructor() { }

  ngOnInit(): void {
  }

}
