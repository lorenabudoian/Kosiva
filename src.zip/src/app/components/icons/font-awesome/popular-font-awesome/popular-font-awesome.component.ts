import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-font-awesome',
  templateUrl: './popular-font-awesome.component.html',
  styleUrls: ['./popular-font-awesome.component.scss']
})
export class PopularFontAwesomeComponent implements OnInit {

  
  icons: any = [{
    name: "coins",
    text: "coins"
},
{
    name: "dollar-sign",
    text: "dollar-sign"
},
{
    name: "share-alt",
    text: "share-alt"
},
{
    name: "sitemap",
    text: "sitemap"
},
{
    name: "wallet",
    text: "wallet"
},
{
    name: "video",
    text: "video"
},
{
    name: "volume-down",
    text: "volume-down"
},
{
    name: "power-off",
    text: "power-off"
},
{
    name: "globe",
    text: "globe"
},
{
    name: "hashtag",
    text: "hashtag"
},
{
    name: "headphones-alt",
    text: "headphones-alt"
},
{
    name: "home",
    text: "home"
},
{
    name: "hourglass",
    text: "hourglass"
},
{
    name: "hourglass-end",
    text: "hourglass-end"
},
{
    name: "plane",
    text: "plane"
},
{
    name: "image",
    text: "image"
},
{
    name: "plane-departure",
    text: "plane-departure"
},
{
    name: "keyboard",
    text: "keyboard"
},
{
    name: "landmark",
    text: "landmark"
},
{
    name: "laptop-code",
    text: "laptop-code"
},

]

  constructor() { }

  ngOnInit(): void {
  }

}
