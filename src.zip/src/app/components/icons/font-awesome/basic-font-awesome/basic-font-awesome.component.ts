import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-font-awesome',
  templateUrl: './basic-font-awesome.component.html',
  styleUrls: ['./basic-font-awesome.component.scss']
})
export class BasicFontAwesomeComponent implements OnInit {
  
  icons: any = [{
    name: "camera",
    text: "camera"
},
{
    name: "bezier-curve",
    text: "bezier-curve"
},
{
    name: "chart-pie",
    text: "chart-pie"
},
{
    name: "calendar-minus",
    text: "calendar-minus"
},
{
    name: "calendar-plus",
    text: "calendar-plus"
},
{
    name: "caret-left",
    text: "caret-left"
},
{
    name: "caret-right",
    text: "caret-right"
},
{
    name: "bell",
    text: "bell"
},
{
    name: "address-book",
    text: "address-book"
},
{
    name: "bug",
    text: "bug"
},
{
    name: "calendar-alt",
    text: "calendar-alt"
},
{
    name: "calendar-check",
    text: "calendar-check"
},
{
    name: "chart-bar",
    text: "chart-bar"
},
{
    name: "check",
    text: "check"
},
{
    name: "cart-plus",
    text: "cart-plus"
},
{
    name: "check-circle",
    text: "check-circle"
},
{
    name: "history",
    text: "history"
},
{
    name: "bell-slash",
    text: "bell-slash"
},
{
    name: "ban",
    text: "ban"
},
{
    name: "atlas",
    text: "atlas"
},
{
    name: "file-code",
    text: "file-code"
},
{
    name: "address-card",
    text: "address-card"
},
{
    name: "folder-open",
    text: "folder-open"
},
{
    name: "bus-alt",
    text: "bus-alt"
},
{
    name: "chevron-down",
    text: "pchevron-down"
},
{
    name: "cloud-download-alt",
    text: "cloud-download-alt"
},
{
    name: "edit",
    text: "edit"
},
{
    name: "eye-slash",
    text: "eye-slash"
},
{
    name: "file",
    text: "file"
},
{
    name: "file-alt",
    text: "file-alt"
},
{
    name: "ice-cream",
    text: "ice-cream"
},
{
    name: "hand-point-up",
    text: "hand-point-up"
},
{
    name: "greater-than",
    text: "greater-than"
},
{
    name: "gamepad",
    text: "gamepad"
},
{
    name: "folder-open",
    text: "folder-open"
},
{
    name: "file-video",
    text: "file-video"
},
{
    name: "credit-card",
    text: "credit-card"
},
{
    name: "comment-dots",
    text: "comment-dots"
},
{
    name: "cogs",
    text: "cogs"
},
{
    name: "cloud-rain",
    text: "cloud-rain"
},
{
    name: "arrow-circle-down",
    text: "arrow-circle-down"
},
{
    name: "arrow-circle-left",
    text: "arrow-circle-left"
},
{
    name: "arrow-circle-right",
    text: "arrow-circle-right"
},
{
    name: "arrows-alt-h",
    text: "arrows-alt-h"
},
{
    name: "arrows-alt-v",
    text: "arrows-alt-v"
},
{
    name: "battery-full",
    text: "battery-full"
},
{
    name: "asterisk",
    text: "asterisk"
},
{
    name: "battery-quarter",
    text: "battery-quarter"
},
{
    name: "at",
    text: "at"
},
{
    name: "atom",
    text: "bus-altatom"
},
{
    name: "bed",
    text: "bed"
},
{
    name: "audio-description",
    text: "audio-description"
},
{
    name: "beer",
    text: "beer"
},
{
    name: "birthday-cake",
    text: "birthday-cake"
},
{
    name: "award",
    text: "award"
},
{
    name: "backspace",
    text: "backspace"
},
{
    name: "bacon",
    text: "bacon"
},
{
    name: "baby-carriage",
    text: "baby-carriage"
},
{
    name: "bible",
    text: "bible"
},
{
    name: "book-medical",
    text: "book-medical"
},
{
    name: "book-open",
    text: "book-open"
},
{
    name: "book-reader",
    text: "book-reader"
},
{
    name: "bowling-ball",
    text: "bowling-ball"
},
{
    name: "box",
    text: "box"
},
{
    name: "box-open",
    text: "box-open"
},
{
    name: "braille",
    text: "braille"
},
{
    name: "brain",
    text: "brain"
},
{
    name: "briefcase-medical",
    text: "briefcase-medical"
},
{
    name: "broadcast-tower",
    text: "broadcast-tower"
},
{
    name: "brush",
    text: "cloud-rain"
},
{
    name: "bullhorn",
    text: "bullhorn"
},
{
    name: "bullseye",
    text: "bullseye"
},
{
    name: "box",
    text: "box"
},
{
    name: "bus-alt",
    text: "bus-alt"
},
{
    name: "business-time",
    text: "business-time"
},
{
    name: "calculator",
    text: "calculator"
},
{
    name: "calendar-times",
    text: "calendar-times"
},
{
    name: "camera-retro",
    text: "camera-retro"
},
{
    name: "capsules",
    text: "capsules"
},
{
    name: "car-battery",
    text: "car-battery"
},
{
    name: "car-side",
    text: "car-side"
},
{
    name: "carrot",
    text: "carrot"
},
{
    name: "caret-up",
    text: "caret-up"
},
{
    name: "cart-arrow-down",
    text: "cart-arrow-down"
},
{
    name: "cat",
    text: "cat"
},
{
    name: "charging-station",
    text: "charging-station"
},
{
    name: "cheese",
    text: "cheese"
},
{
    name: "chess",
    text: "chess"
},
{
    name: "chess-bishop",
    text: "chess-bishop"
},
{
    name: "chess-board",
    text: "chess-board"
},
{
    name: "chess-king",
    text: "chess-king"
},
{
    name: "chess-knight",
    text: "chess-knight"
},
{
    name: "chess-pawn",
    text: "chess-pawn"
},
{
    name: "chess-queen",
    text: "chess-queen"
},
{
    name: "chess-rook",
    text: "chess-rook"
},
{
    name: "child",
    text: "child"
},
{
    name: "dice-six",
    text: "dice-six"
},
{
    name: "church",
    text: "church"
},
{
    name: "circle",
    text: "circle"
},
{
    name: "city",
    text: "city"
},
{
    name: "clinic-medical",
    text: "clinic-medical"
},
{
    name: "clipboard-check",
    text: "clipboard-check"
},
{
    name: "clipboard",
    text: "clipboard"
},
{
    name: "clipboard-list",
    text: "clipboard-list"
},
{
    name: "clock",
    text: "clock"
},
{
    name: "clone",
    text: "clone"
},
{
    name: "closed-captioning",
    text: "closed-captioning"
},
{
    name: "cloud-meatball",
    text: "cloud-meatball"
},
{
    name: "cloud-moon",
    text: "cloud-moon"
},
{
    name: "cloud-moon-rain",
    text: "cloud-moon-rain"
},
{
    name: "cloud-rain",
    text: "cloud-rain"
},
{
    name: "cloud-showers-heavy",
    text: "cloud-showers-heavy"
},
{
    name: "cloud-sun",
    text: "cloud-sun"
},
{
    name: "cocktail",
    text: "cocktail"
},
{
    name: "code",
    text: "code"
},
{
    name: "code-branch",
    text: "code-branch"
},
{
    name: "crop",
    text: "crop"
},
{
    name: "coffee",
    text: "coffee"
},
{
    name: "cog",
    text: "cog"
},
{
    name: "cogs",
    text: "cogs"
},
{
    name: "coins",
    text: "coins"
},
{
    name: "columns",
    text: "columns"
},
{
    name: "comment",
    text: "comment"
},
{
    name: "comment-alt",
    text: "comment-alt"
},
{
    name: "comment-slash",
    text: "comment-slash"
},
{
    name: "compact-disc",
    text: "compact-disc"
},
{
    name: "compass",
    text: "compass"
},
{
    name: "compress",
    text: "compress"
},
{
    name: "crop-alt",
    text: "crop-alt"
},
{
    name: "compress-arrows-alt",
    text: "compress-arrows-alt"
},
{
    name: "concierge-bell",
    text: "concierge-bell"
},
{
    name: "database",
    text: "database"
},
{
    name: "cookie",
    text: "cookie"
},
{
    name: "cookie-bite",
    text: "cookie-bite"
},
{
    name: "copyright",
    text: "copyright"
},
{
    name: "couch",
    text: "couch"
},
{
    name: "cross",
    text: "cross"
},
{
    name: "crosshairs",
    text: "crosshairs"
},
{
    name: "crown",
    text: "crown"
},
{
    name: "crutch",
    text: "crutch"
}
]

  constructor() { }

  ngOnInit(): void {
  }

}
