import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-design',
  templateUrl: './material-design.component.html',
  styleUrls: ['./material-design.component.scss']
})
export class MaterialDesignComponent implements OnInit {

  icons: any = [{
    name: "pause_circle_outline",
    propriety: "Outlined:",
    code: ".material-icons-outlined",
    class: "material-icons-outlined  material-ic"
},
{
    name: "pause_circle_filled",
    propriety: "Filled:",
    code: ".material-icons",
    class: " material-ic"
},
{
    name: "add",
    propriety: "Size:",
    code: ".material-icons.md-18/24/36/48",
    class: " material-ic"
},
{
    name: "face",
    propriety: "Color:",
    code: ".material-icons.md-dark/light",
    class: "md-light"
},
{
    name: "skip_next",
    propriety: "Disabled",
    code: ".md-inactive",
    class: "md-inactive md-light"
},
]
  constructor() { }

  ngOnInit(): void {
  }

}
