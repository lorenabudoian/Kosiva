import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-icons',
  templateUrl: './basic-icons.component.html',
  styleUrls: ['./basic-icons.component.scss']
})
export class BasicIconsComponent implements OnInit {

 
  icons: any = [{
    name: "add",
    text: "add"
},
{
    name: "where_to_vote",
    text: "where_to_vote"
},
{
    name: "text_format",
    text: "text_format"
},
{
    name: "filter_list",
    text: "filter_list"
},
{
    name: "create",
    text: "create"
},
{
    name: "block",
    text: "block"
},
{
    name: "flag",
    text: "flag"
},
{
    name: "drafts",
    text: "drafts"
},
{
    name: "next_week",
    text: "next_week"
},
{
    name: "brightness_7",
    text: "brightness_7"
},
{
    name: "apps",
    text: "apps"
},
{
    name: "arrow_back",
    text: "arrow_back"
},
{
    name: "arrow_back_ios",
    text: "arrow_back_ios"
},
{
    name: "arrow_downward",
    text: "arrow_downward"
},
{
    name: "arrow_forward",
    text: "arrow_forward"
},
{
    name: "arrow_upward",
    text: "arrow_upward"
},
{
    name: "cancel",
    text: "cancel"
},
{
    name: "check",
    text: "check"
},
{
    name: "chevron_left",
    text: "chevron_left"
},
{
    name: "chevron_right",
    text: "chevron_right"
},
{
    name: "cloud_done",
    text: "cloud_done"
},
{
    name: "attachment",
    text: "attachment"
},
{
    name: "cloud",
    text: "cloud"
},
{
    name: "cloud_download",
    text: "cloud_download"
},
{
    name: "cloud_off",
    text: "cloud_off"
},
{
    name: "cloud_upload",
    text: "cloud_upload"
},
{
    name: "create_new_folder",
    text: "create_new_folder"
},
{
    name: "folder",
    text: "folder"
},
{
    name: "folder_open",
    text: "folder_open"
},
{
    name: "train",
    text: "train"
},
{
    name: "360",
    text: "360"
},
{
    name: "local_airport",
    text: "local_airport"
},
{
    name: "local_dining",
    text: "local_dining"
},
{
    name: "my_location",
    text: "my_location"
},
{
    name: "navigation",
    text: "navigation"
},
{
    name: "near_me",
    text: "near_me"
},
{
    name: "local_grocery_store",
    text: "local_grocery_store"
},
{
    name: "local_phone",
    text: "local_phone"
},
{
    name: "directions_car",
    text: "directions_car"
},
{
    name: "timer",
    text: "timer"
},
{
    name: "3d_rotation",
    text: "3d_rotation"
},
{
    name: "account_balance",
    text: "account_balance"
},
{
    name: "account_balance_wallet",
    text: "account_balance_wallet"
},
{
    name: "account_box",
    text: "account_box"
},
{
    name: "account_circle",
    text: "account_circle"
},
{
    name: "alarm_add",
    text: "alarm_add"
},
{
    name: "arrow_forward",
    text: "alarm_off"
},
{
    name: "alarm_on",
    text: "alarm_on"
},
{
    name: "all_inbox",
    text: "all_inbox"
},
{
    name: "android",
    text: "android"
},
{
    name: "announcement",
    text: "announcement"
},
{
    name: "arrow_right_alt",
    text: "arrow_right_alt"
},
{
    name: "aspect_ratio",
    text: "aspect_ratio"
},
{
    name: "assessment",
    text: "assessment"
},
{
    name: "assignment",
    text: "assignment"
},
{
    name: "assignment_ind",
    text: "assignment_ind"
},
{
    name: "assignment_return",
    text: "assignment_return"
},
{
    name: "assignment_returned",
    text: "assignment_returned"
},
{
    name: "assignment_turned_in",
    text: "assignment_turned_in"
},
{
    name: "autorenew",
    text: "autorenew"
},
{
    name: "backup",
    text: "backup"
},
{
    name: "book",
    text: "book"
},
{
    name: "bookmark",
    text: "bookmark"
},
{
    name: "bookmarks",
    text: "bookmarks"
},
{
    name: "bug_report",
    text: "bug_report"
},
{
    name: "build",
    text: "build"
},
{
    name: "cached",
    text: "cached"
},
{
    name: "cancel_schedule_send",
    text: "cancel_schedule_send"
},
{
    name: "card_giftcard",
    text: "card_giftcard"
},
{
    name: "card_membership",
    text: "card_membership"
},
{
    name: "card_travel",
    text: "card_travel"
},
{
    name: "change_history",
    text: "change_history"
},
{
    name: "check_circle",
    text: "check_circle"
},
{
    name: "chrome_reader_mode",
    text: "chrome_reader_mode"
},
{
    name: "class",
    text: "class"
},
{
    name: "commute",
    text: "commute"
},
{
    name: "compare_arrows",
    text: "compare_arrows"
},
{
    name: "contact_support",
    text: "contact_support"
},
{
    name: "contactless",
    text: "contactless"
},
{
    name: "copyright",
    text: "copyright"
},
{
    name: "dashboard",
    text: "dashboard"
},
{
    name: "date_range",
    text: "date_range"
},
{
    name: "delete",
    text: "delete"
},
{
    name: "delete_forever",
    text: "delete_forever"
},
{
    name: "delete_outline",
    text: "delete_outline"
},
{
    name: "description",
    text: "description"
},
{
    name: "dns",
    text: "dns"
},
{
    name: "done",
    text: "done"
},
{
    name: "done_all",
    text: "done_all"
},
{
    name: "done_outline",
    text: "done_outline"
},
{
    name: "euro_symbol",
    text: "euro_symbol"
},
{
    name: "event",
    text: "event"
},
{
    name: "exit_to_app",
    text: "exit_to_app"
},
{
    name: "explore",
    text: "explore"
},
{
    name: "favorite",
    text: "favorite"
},
{
    name: "feedback",
    text: "feedback"
},
{
    name: "find_in_page",
    text: "find_in_page"
},
{
    name: "find_replace",
    text: "find_replace"
},
{
    name: "flight_land",
    text: "flight_land"
},
{
    name: "flight_takeoff",
    text: "flight_takeoff"
},
{
    name: "flip_to_front",
    text: "flip_to_front"
},
{
    name: "g_translate",
    text: "g_translate"
},
{
    name: "gavel",
    text: "gavel"
},
{
    name: "get_app",
    text: "get_app"
},
{
    name: "grade",
    text: "grade"
},
{
    name: "group_work",
    text: "group_work"
},
{
    name: "help",
    text: "help"
},
{
    name: "cake",
    text: "cake"
},
{
    name: "deck",
    text: "deck"
},
{
    name: "domain",
    text: "domain"
},
{
    name: "emoji_events",
    text: "emoji_events"
},
{
    name: "emoji_flags",
    text: "emoji_flags"
},
{
    name: "emoji_objects",
    text: "emoji_objects"
},
{
    name: "emoji_people",
    text: "emoji_people"
},
{
    name: "group",
    text: "group"
},
{
    name: "group_add",
    text: "group_add"
},
{
    name: "mood",
    text: "mood"
},
{
    name: "notifications",
    text: "notifications"
},
{
    name: "notifications_active",
    text: "notifications_active"
},
{
    name: "notifications_off",
    text: "notifications_off"
},
{
    name: "notifications_paused",
    text: "notifications_paused"
},
{
    name: "party_mode",
    text: "party_mode"
},
{
    name: "person_add",
    text: "person_add"
},
{
    name: "person_outline",
    text: "person_outline"
},
{
    name: "plus_one",
    text: "plus_one"
},
{
    name: "public",
    text: "public"
},
{
    name: "school",
    text: "school"
},
{
    name: "share",
    text: "share"
},
{
    name: "single_bed",
    text: "single_bed"
},
{
    name: "sports_baseball",
    text: "sports_baseball"
},
{
    name: "sports_basketball",
    text: "sports_basketball"
},
{
    name: "sports_esports",
    text: "sports_esports"
},
{
    name: "sports_football",
    text: "sports_football"
},
{
    name: "sports_handball",
    text: "sports_handball"
},
{
    name: "sports_kabaddi",
    text: "sports_kabaddi"
},
{
    name: "sports_mma",
    text: "sports_mma"
},
{
    name: "sports_motorsports",
    text: "sports_motorsports"
},
{
    name: "sports_soccer",
    text: "sports_soccer"
},
{
    name: "sports_tennis",
    text: "sports_tennis"
},
{
    name: "thumb_up_alt",
    text: "thumb_up_alt"
},
{
    name: "thumb_down_alt",
    text: "thumb_down_alt"
},
{
    name: "whatshot",
    text: "whatshot"
},
{
    name: "cast_connected",
    text: "cast_connected"
},
{
    name: "desktop_mac",
    text: "desktop_mac"
},
]

  constructor() { }

  ngOnInit(): void {
  }

}
