import {  Component,  OnInit} from '@angular/core';

@Component({
  selector: 'app-popular-icons',
  templateUrl: './popular-icons.component.html',
  styleUrls: ['./popular-icons.component.scss']
})
export class PopularIconsComponent implements OnInit {


  icons: any = [{
          name: "add_ic_call",
          text: "add_ic_call"
      },
      {
          name: "alternate_email",
          text: "alternate_email"
      },
      {
          name: "call_end",
          text: "call_end"
      },
      {
          name: "call_made",
          text: "call_made"
      },
      {
          name: "call_missed",
          text: "call_missed"
      },
      {
          name: "phonelink_erase",
          text: "phonelink_erase"
      },
      {
          name: "phonelink_lock",
          text: "phonelink_lock"
      },
      {
          name: "portable_wifi_off",
          text: "portable_wifi_off"
      },
      {
          name: "fast_forward",
          text: "fast_forward"
      },
      {
          name: "fast_rewind",
          text: "fast_rewind"
      },
      {
          name: "av_timer",
          text: "av_timer"
      },
      {
          name: "control_camera",
          text: "control_camera"
      },
      {
          name: "not_interested",
          text: "not_interested"
      },
      {
          name: "pause_circle_outline",
          text: "pause_circle_outline"
      },
      {
          name: "replay_10",
          text: "replay_10"
      },
      {
          name: "shuffle",
          text: "shuffle"
      },
      {
          name: "skip_next",
          text: "skip_next"
      },
      {
          name: "slow_motion_video",
          text: "slow_motion_video"
      },
      {
          name: "speed",
          text: "speed"
      },
      {
          name: "replay",
          text: "replay"
      },
   

  ]
  constructor() {}

  ngOnInit(): void {}

}