import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animated-loaders',
  templateUrl: './animated-loaders.component.html',
  styleUrls: ['./animated-loaders.component.scss']
})
export class AnimatedLoadersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
