import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loaders-size',
  templateUrl: './loaders-size.component.html',
  styleUrls: ['./loaders-size.component.scss']
})
export class LoadersSizeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
