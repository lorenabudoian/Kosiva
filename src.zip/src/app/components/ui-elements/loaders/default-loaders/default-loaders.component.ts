import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-loaders',
  templateUrl: './default-loaders.component.html',
  styleUrls: ['./default-loaders.component.scss']
})
export class DefaultLoadersComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
