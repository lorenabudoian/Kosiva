import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loaders-with-text',
  templateUrl: './loaders-with-text.component.html',
  styleUrls: ['./loaders-with-text.component.scss']
})
export class LoadersWithTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
