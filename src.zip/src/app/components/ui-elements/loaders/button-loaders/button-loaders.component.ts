import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-loaders',
  templateUrl: './button-loaders.component.html',
  styleUrls: ['./button-loaders.component.scss']
})
export class ButtonLoadersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
