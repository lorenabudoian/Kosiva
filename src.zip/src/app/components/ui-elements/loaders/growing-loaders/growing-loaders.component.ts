import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-growing-loaders',
  templateUrl: './growing-loaders.component.html',
  styleUrls: ['./growing-loaders.component.scss']
})
export class GrowingLoadersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
