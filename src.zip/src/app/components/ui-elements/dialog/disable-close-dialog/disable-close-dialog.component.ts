import { Component, } from '@angular/core';
import { MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-disable-close-dialog-content',
  templateUrl: './disable-close-dialog-content.html',
  styleUrls: ['./disable-close-dialog.component.scss'],
})
export class DisableCloseDialogContent {}

@Component({
  selector: 'app-disable-close-dialog',
  templateUrl: './disable-close-dialog.component.html',
  styleUrls: ['./disable-close-dialog.component.scss']
})

export class DisableCloseDialogComponent{

  constructor(public interactivedialog: MatDialog) {}

  openDialog() {
    const dialogRefthree = this.interactivedialog.open(DisableCloseDialogContent, {disableClose:true} );

    dialogRefthree.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}


