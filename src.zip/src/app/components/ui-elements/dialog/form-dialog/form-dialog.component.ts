import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-form-dialog-content',
  templateUrl: './form-dialog-content.html',
  styleUrls: ['./form-dialog.component.scss',],
})
export class FormDialogContent{}

@Component({
  selector: 'app-form-dialog',
  templateUrl: './form-dialog.component.html',
  styleUrls: ['./form-dialog.component.scss']
})
export class FormDialogComponent{

  constructor(public interactivedialog: MatDialog) {}

  openDialog() {
    const dialogform = this.interactivedialog.open(FormDialogContent);

    dialogform.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}


