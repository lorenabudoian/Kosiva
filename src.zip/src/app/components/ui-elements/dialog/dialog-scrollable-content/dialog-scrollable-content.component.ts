import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'dialog-content-example-dialog',
  templateUrl: './dialog-content-example-dialog.html',
  styleUrls: ['./dialog-scrollable-content.component.scss',]
})
export class DialogContentExampleDialog {}


@Component({
  selector: 'app-dialog-scrollable-content',
  templateUrl: './dialog-scrollable-content.component.html',
  styleUrls: ['./dialog-scrollable-content.component.scss']
})
export class DialogScrollableContentComponent {

  
  constructor(public dialog: MatDialog) {}

  openDialog() {
    const dialogRef = this.dialog.open(DialogContentExampleDialog);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
