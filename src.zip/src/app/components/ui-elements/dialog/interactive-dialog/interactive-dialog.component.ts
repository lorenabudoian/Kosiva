import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-interactive-dialog-content',
  templateUrl: './interactive-dialog-content.html',
  styleUrls: ['./interactive-dialog.component.scss']
})
export class InteractiveDialogContent {}

@Component({
  selector: 'app-interactive-dialog',
  templateUrl: './interactive-dialog.component.html',
  styleUrls: ['./interactive-dialog.component.scss']
})

export class InteractiveDialogComponent{

  constructor(public interactivedialog: MatDialog) {}

  openDialog() {
    const dialogReftwo = this.interactivedialog.open(InteractiveDialogContent);

    dialogReftwo.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}




