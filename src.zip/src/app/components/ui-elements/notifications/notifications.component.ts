import { Component, OnInit } from '@angular/core';
import { AppPublicNotifications } from 'src/app/services/public-noti.service';
import { NotificationsModel } from '../../../shared/trigger-notifications.model';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  constructor( public notificationService: AppPublicNotifications ) { }

  ngOnInit(): void {
    this.notificationService.showNotice().subscribe( data => {
      console.log(data);
    })   
  }

  triggerNotice() {
    this.notificationService.triggerNotice( new NotificationsModel('warning', 'Opps, there was a problem saving your changes.') );
  }

}
