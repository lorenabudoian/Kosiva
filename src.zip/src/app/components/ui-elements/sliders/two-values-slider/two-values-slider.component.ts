import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-values-slider',
  templateUrl: './two-values-slider.component.html',
  styleUrls: ['./two-values-slider.component.scss']
})
export class TwoValuesSliderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
