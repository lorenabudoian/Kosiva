import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-thumb-label-formatting',
  templateUrl: './custom-thumb-label-formatting.component.html',
  styleUrls: ['./custom-thumb-label-formatting.component.scss']
})
export class CustomThumbLabelFormattingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
