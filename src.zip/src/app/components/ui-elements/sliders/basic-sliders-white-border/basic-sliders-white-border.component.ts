import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-sliders-white-border',
  templateUrl: './basic-sliders-white-border.component.html',
  styleUrls: ['./basic-sliders-white-border.component.scss']
})
export class BasicSlidersWhiteBorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
