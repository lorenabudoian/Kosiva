import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vertical-sliders',
  templateUrl: './vertical-sliders.component.html',
  styleUrls: ['./vertical-sliders.component.scss']
})
export class VerticalSlidersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
