import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thumb-label-white-border',
  templateUrl: './thumb-label-white-border.component.html',
  styleUrls: ['./thumb-label-white-border.component.scss']
})
export class ThumbLabelWhiteBorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
