import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-basic-sliders',
  templateUrl: './basic-sliders.component.html',
  styleUrls: ['./basic-sliders.component.scss'],
  
})
export class BasicSlidersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
   
  }
  

}
