import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vertical-slider-white-border',
  templateUrl: './vertical-slider-white-border.component.html',
  styleUrls: ['./vertical-slider-white-border.component.scss']
})
export class VerticalSliderWhiteBorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
