import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inverted-basic-sliders',
  templateUrl: './inverted-basic-sliders.component.html',
  styleUrls: ['./inverted-basic-sliders.component.scss']
})
export class InvertedBasicSlidersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
