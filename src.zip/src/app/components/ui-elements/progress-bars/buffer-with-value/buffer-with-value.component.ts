import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buffer-with-value',
  templateUrl: './buffer-with-value.component.html',
  styleUrls: ['./buffer-with-value.component.scss']
})
export class BufferWithValueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
