import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-progress-bar',
  templateUrl: './bootstrap-progress-bar.component.html',
  styleUrls: ['./bootstrap-progress-bar.component.scss']
})
export class BootstrapProgressBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
