import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indeterminate-progress-bars',
  templateUrl: './indeterminate-progress-bars.component.html',
  styleUrls: ['./indeterminate-progress-bars.component.scss']
})
export class IndeterminateProgressBarsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
