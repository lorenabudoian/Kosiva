import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-query-progress-bars',
  templateUrl: './query-progress-bars.component.html',
  styleUrls: ['./query-progress-bars.component.scss']
})
export class QueryProgressBarsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
