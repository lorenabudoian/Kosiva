import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress-bars-height',
  templateUrl: './progress-bars-height.component.html',
  styleUrls: ['./progress-bars-height.component.scss']
})
export class ProgressBarsHeightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
