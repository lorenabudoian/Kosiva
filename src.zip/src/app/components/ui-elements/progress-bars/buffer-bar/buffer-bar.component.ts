import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buffer-bar',
  templateUrl: './buffer-bar.component.html',
  styleUrls: ['./buffer-bar.component.scss']
})
export class BufferBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
