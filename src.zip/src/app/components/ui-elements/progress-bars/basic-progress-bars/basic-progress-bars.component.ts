import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-progress-bars',
  templateUrl: './basic-progress-bars.component.html',
  styleUrls: ['./basic-progress-bars.component.scss']
})
export class BasicProgressBarsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
