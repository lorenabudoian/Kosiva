import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stripped-progress-bar',
  templateUrl: './stripped-progress-bar.component.html',
  styleUrls: ['./stripped-progress-bar.component.scss']
})
export class StrippedProgressBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
