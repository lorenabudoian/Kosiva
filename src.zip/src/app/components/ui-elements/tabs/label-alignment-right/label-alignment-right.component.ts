import { Component, OnInit } from '@angular/core';

interface Pages {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-label-alignment-right',
  templateUrl: './label-alignment-right.component.html',
  styleUrls: ['./label-alignment-right.component.scss']
})
export class LabelAlignmentRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  properties: Pages[] = [
    { value: 'pages', viewValue: 'Pages only' },
    { value: 'custom', viewValue: 'Custom' },
    { value: 'disable', viewValue: 'Disable' }
  ];


}
