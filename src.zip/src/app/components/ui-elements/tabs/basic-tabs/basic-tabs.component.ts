import { Component, OnInit} from '@angular/core';

interface Pages {
  value: string;
  viewValue: string;
}

export interface Transaction {
  clientName: string;
  clientJob:string;
  cost: number;
  orderId:number;
  profit:number;
  city:string;
  status:string;
}

@Component({
  selector: 'app-basic-tabs',
  templateUrl: './basic-tabs.component.html',
  styleUrls: ['./basic-tabs.component.scss']
})

export class BasicTabsComponent implements OnInit {

  ngOnInit() {
  }

  properties: Pages[] = [
    { value: 'pages', viewValue: 'Pages only' },
    { value: 'custom', viewValue: 'Custom' },
    { value: 'disable', viewValue: 'Disable' }
  ];


}
