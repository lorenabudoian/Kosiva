import { Component, OnInit } from '@angular/core';

interface Pages {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-slow-animation-tabs',
  templateUrl: './slow-animation-tabs.component.html',
  styleUrls: ['./slow-animation-tabs.component.scss']
})
export class SlowAnimationTabsComponent implements OnInit {

  properties: Pages[] = [
    { value: 'pages', viewValue: 'Pages only' },
    { value: 'custom', viewValue: 'Custom' },
    { value: 'disable', viewValue: 'Disable' }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
