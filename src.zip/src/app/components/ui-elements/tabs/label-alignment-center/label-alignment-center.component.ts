import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';


interface Pages {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-label-alignment-center',
  templateUrl: './label-alignment-center.component.html',
  styleUrls: ['./label-alignment-center.component.scss']
})
export class LabelAlignmentCenterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  properties: Pages[] = [
    { value: 'pages', viewValue: 'Pages only' },
    { value: 'custom', viewValue: 'Custom' },
    { value: 'disable', viewValue: 'Disable' }
  ];

}
