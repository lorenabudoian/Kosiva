import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gradient-slides',
  templateUrl: './gradient-slides.component.html',
  styleUrls: ['./gradient-slides.component.scss']
})
export class GradientSlidesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
