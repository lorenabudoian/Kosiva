import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-slides',
  templateUrl: './basic-slides.component.html',
  styleUrls: ['./basic-slides.component.scss']
})
export class BasicSlidesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
