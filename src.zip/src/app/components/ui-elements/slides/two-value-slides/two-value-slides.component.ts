import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-value-slides',
  templateUrl: './two-value-slides.component.html',
  styleUrls: ['./two-value-slides.component.scss']
})
export class TwoValueSlidesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
