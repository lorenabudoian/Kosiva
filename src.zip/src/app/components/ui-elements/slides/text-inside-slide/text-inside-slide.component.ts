import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-inside-slide',
  templateUrl: './text-inside-slide.component.html',
  styleUrls: ['./text-inside-slide.component.scss']
})
export class TextInsideSlideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
