import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slide-with-icon',
  templateUrl: './slide-with-icon.component.html',
  styleUrls: ['./slide-with-icon.component.scss']
})
export class SlideWithIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
