import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toggle-slides',
  templateUrl: './toggle-slides.component.html',
  styleUrls: ['./toggle-slides.component.scss']
})
export class ToggleSlidesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
