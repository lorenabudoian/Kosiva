import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colors',
  templateUrl: './colors.component.html',
  styleUrls: ['./colors.component.scss']
})
export class ColorsComponent implements OnInit {
    
    colors = [{
      name: "primary",
      code: "#6344df"
  },
  {
      name: "secondary",
      code: "#e99502"
  },
  {
      name: "pink",
      code: "#d90c73"
  },
  {
      name: "green",
      code: "#4ecdbb"
  },
  {
      name: "dark",
      code: "#343a40"
  },
  ];

  colorstyletwo = [{
      name: "royal",
      code: "#e74c3c"
  },
  {
      name: "lavender",
      code: "#ac92ea"
  },
  {
      name: "aqua",
      code: "#39a9d4"
  },
  {
      name: "rose",
      code: "#d770ad"
  },
  {
      name: "purple",
      code: "#5b78c5"
  },

  ];

  gradientcolors = [{
      name: "gradient-pink",
      class: "gradient-pink",
      code: "#f650a1, #ff7478"
  },
  {
      name: "gradient-blue",
      class: "gradient-blue",
      code: "#6cd2fb, #0f4fdd"
  },
  {
      name: "gradient-yellow",
      class: "gradient-yellow",
      code: "#ff8c39, #fefb44"
  },
  {
      name: "gradient-green",
      class: "gradient-green",
      code: "#08fe9b, #0079fc"
  },
  {
      name: "gradient-red",
      class: "gradient-red",
      code: "#790161, #ec0b51"
  },
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
