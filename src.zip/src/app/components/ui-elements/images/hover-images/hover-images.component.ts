import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hover-images',
  templateUrl: './hover-images.component.html',
  styleUrls: ['./hover-images.component.scss']
})
export class HoverImagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
