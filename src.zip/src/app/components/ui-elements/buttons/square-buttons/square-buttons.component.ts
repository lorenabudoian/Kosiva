import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-square-buttons',
  templateUrl: './square-buttons.component.html',
  styleUrls: ['./square-buttons.component.scss']
})
export class SquareButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
