import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fab-buttons',
  templateUrl: './fab-buttons.component.html',
  styleUrls: ['./fab-buttons.component.scss']
})
export class FabButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
