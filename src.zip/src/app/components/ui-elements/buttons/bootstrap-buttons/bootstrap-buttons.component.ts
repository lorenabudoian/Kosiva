import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-buttons',
  templateUrl: './bootstrap-buttons.component.html',
  styleUrls: ['./bootstrap-buttons.component.scss']
})
export class BootstrapButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
