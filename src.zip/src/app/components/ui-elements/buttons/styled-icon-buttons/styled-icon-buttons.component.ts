import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styled-icon-buttons',
  templateUrl: './styled-icon-buttons.component.html',
  styleUrls: ['./styled-icon-buttons.component.scss']
})
export class StyledIconButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
