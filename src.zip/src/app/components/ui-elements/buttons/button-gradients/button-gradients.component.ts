import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-gradients',
  templateUrl: './button-gradients.component.html',
  styleUrls: ['./button-gradients.component.scss']
})
export class ButtonGradientsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
