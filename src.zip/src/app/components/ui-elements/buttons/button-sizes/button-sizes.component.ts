import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-sizes',
  templateUrl: './button-sizes.component.html',
  styleUrls: ['./button-sizes.component.scss']
})
export class ButtonSizesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
