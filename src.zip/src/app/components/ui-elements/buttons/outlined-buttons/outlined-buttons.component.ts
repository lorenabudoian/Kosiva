import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outlined-buttons',
  templateUrl: './outlined-buttons.component.html',
  styleUrls: ['./outlined-buttons.component.scss']
})
export class OutlinedButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
