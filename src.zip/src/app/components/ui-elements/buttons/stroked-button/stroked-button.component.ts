import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stroked-button',
  templateUrl: './stroked-button.component.html',
  styleUrls: ['./stroked-button.component.scss']
})
export class StrokedButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
