import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rounded-buttons',
  templateUrl: './rounded-buttons.component.html',
  styleUrls: ['./rounded-buttons.component.scss']
})
export class RoundedButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
