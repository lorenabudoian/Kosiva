import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-square-badges',
  templateUrl: './square-badges.component.html',
  styleUrls: ['./square-badges.component.scss']
})
export class SquareBadgesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
