import {Component, ViewChild} from '@angular/core';
import {MatAccordion} from '@angular/material/expansion';


@Component({
  selector: 'app-expansion-panel-answers',
  templateUrl: './expansion-panel-answers.component.html',
  styleUrls: ['./expansion-panel-answers.component.scss']
})
export class ExpansionPanelAnswersComponent {
  @ViewChild(MatAccordion) accordion: MatAccordion;

  constructor() { }

  ngOnInit(): void {
  }

}
