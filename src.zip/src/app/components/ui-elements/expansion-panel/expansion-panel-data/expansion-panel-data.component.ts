import {Component, ViewChild} from '@angular/core';
import {MatAccordion} from '@angular/material/expansion';

@Component({
  selector: 'app-expansion-panel-data',
  templateUrl: './expansion-panel-data.component.html',
  styleUrls: ['./expansion-panel-data.component.scss']
})
export class ExpansionPanelDataComponent {

  @ViewChild(MatAccordion) accordion: MatAccordion;


}
