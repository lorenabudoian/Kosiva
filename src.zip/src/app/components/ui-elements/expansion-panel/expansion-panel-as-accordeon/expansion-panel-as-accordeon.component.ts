import {Component} from '@angular/core';

@Component({
  selector: 'app-expansion-panel-as-accordeon',
  templateUrl: './expansion-panel-as-accordeon.component.html',
  styleUrls: ['./expansion-panel-as-accordeon.component.scss']
})
export class ExpansionPanelAsAccordeonComponent {

  step = 0;

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
