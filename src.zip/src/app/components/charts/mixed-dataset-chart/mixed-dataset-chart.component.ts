import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-mixed-dataset-chart',
    templateUrl: './mixed-dataset-chart.component.html',
    styleUrls: ['./mixed-dataset-chart.component.scss']
})
export class MixedDatasetChartComponent implements AfterViewInit {


    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit(): void {

        var earnings = this.chartElement.nativeElement.querySelector('#ks-daily-sales');
        var ctx = earnings.getContext('2d');

        var gradientStroke = ctx.createLinearGradient(1300, 90, 100, 600);

        gradientStroke.addColorStop(0.3, "#beb242");
        gradientStroke.addColorStop(0.5, "#a6218a");
        gradientStroke.addColorStop(0.9, "#1e2cbf");
        var data = {
            labels: ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
            datasets: [{
                    label: "All Sales",
                    backgroundColor: "#7c13ff2e",
                    borderColor: "#7c13ff",
                    borderWidth: 2,
                    hoverBackgroundColor: "rgba(255,99,132,0.4)",
                    hoverBorderColor: "rgba(255,99,132,1)",
                    data: [90, 78, 65, 54, 35, 50, 30, 15, 10, 35, 90, 78, 65, 54, 35, 50, 30, 15, 10, 35],
                },
                {
                    label: 'Earnings',
                    borderColor: '#28156e',
                    pointBorderColor: gradientStroke,
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 0.2,
                    backgroundColor: '#240a614d',
                    borderWidth: 2,
                    data: [35, 90, 78, 65, 54, 35, 50, 30, 15, 10, 35, 90, 78, 65, 54, 35, 50, 30, 15, 10],
                },
                {
                    label: 'Earnings',
                    borderColor: gradientStroke,
                    pointBorderColor: gradientStroke,
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 1,
                    type: 'line',
                    borderWidth: 1,
                    data: [130, 131, 132, 130, 141, 140, 143, 128, 127, 132, 127, 151, 152, 159, 140, 130, 80, 100, 70, 80, 60,
                        41, 32, 30, 41, 40, 43, 68, 67, 62
                    ]
                }
            ]
        };

        var options = {
            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 160,
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        min: 0
                    },

                    gridLines: {
                        color: '#0d0827',
                        lineWidth: 0.5,
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {
                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }
            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                fontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };

        var myBarChart = new chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });

    }


}