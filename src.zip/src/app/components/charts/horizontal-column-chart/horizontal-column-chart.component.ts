import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-horizontal-column-chart',
    templateUrl: './horizontal-column-chart.component.html',
    styleUrls: ['./horizontal-column-chart.component.scss']
})
export class HorizontalColumnChartComponent implements AfterViewInit {

    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit(): void {

        var earnings = this.chartElement.nativeElement.querySelector('#ks-sales')
        var ctx = earnings.getContext('2d');


        var data = {
            labels: ["USA", "UK", "FR", "RO", "NZ", "FR", "RO", "NZ"],
            datasets: [{
                label: "All Sales",
                backgroundColor: "rgba(255,99,132,0.2)",
                borderColor: "rgba(255,99,132,1)",
                borderWidth: 2,
                hoverBackgroundColor: "rgba(255,99,132,0.4)",
                hoverBorderColor: "rgba(255,99,132,1)",
                data: [80, 68, 75, 64, 70, 75, 64, 70],
            }]
        };

        var options = {
            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        max: 90,
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        fontStyle: "normal",
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        fontColor: '#6c75a8',
                    },

                    gridLines: {
                        color: '#0d0827',
                        lineWidth: 0.5,
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {
                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }

            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                fontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };

        var myBarChart = new chart(ctx, {
            type: 'horizontalBar',
            data: data,
            options: options
        });

    }

}