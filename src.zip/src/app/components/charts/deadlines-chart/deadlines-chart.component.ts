import {
  Component,
  AfterViewInit,
  ViewChild,
  ElementRef
} from '@angular/core';
import * as Chart from 'chart.js';

@Component({
  selector: 'app-deadlines-chart',
  templateUrl: './deadlines-chart.component.html',
  styleUrls: ['./deadlines-chart.component.scss']
})

export class DeadlinesChartComponent implements AfterViewInit {

  @ViewChild(
      'angularIdElement', {
          static: false
      }
  ) chartElement: ElementRef < any > ;

  constructor() {

      Chart.defaults.timeline = Chart.defaults.horizontalBar;
      Chart.controllers.timeline = Chart.controllers.horizontalBar.extend({
          initialize: function() {
              return Chart.controllers.bar.prototype.initialize.apply(this, arguments);
          }
      });

      Chart.pluginService.register({
          beforeInit: function(chart) {
              if (chart.config.type === 'timeline') {
                  var config = chart.config;

                  var data = config.data.datasets[0].data;

                  var min = new Date(data[0][0].getFullYear(), data[0][0].getMonth(), data[0][0].getDate());
                  var max = new Date(data[0][0].getFullYear() + 1, data[0][0].getMonth(), data[0][0].getDate() + 1);
                  var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

                  function toDate(date) {
                      var date: any = new Date(date);
                      var monthIndex = date.getMonth();
                      return months[monthIndex];
                  }

                  config.options.scales.xAxes[0].ticks.callback = toDate;
                  config.options.scales.xAxes[0].ticks.min = min;
                  config.options.scales.xAxes[0].ticks.max = max;
                  config.options.scales.xAxes[0].ticks.fixedStepSize = 1000 * 60 * 60;
                  config.options.scales.xAxes[0].ticks.minRotation = 90

                  // create a dummy dataset with background color transparent ending at the start time
                  config.data.datasets.unshift({
                      backgroundColor: 'rgba(0, 0, 0, 0)',
                      data: data.map(function(e) {
                          return e[0];
                      })
                  });

                  config.data.datasets[1].data = data.map(function(e) {
                      return e[1] - e[0];
                  });
              }
          }
      });
  }

  ngAfterViewInit() {

      var ctx = this.chartElement.nativeElement.querySelector("#chartCanvas").getContext("2d");
      Chart.defaults.global.defaultFontColor = '#9398b8';

      var myChart = new Chart(ctx, {
          type: 'timeline',
          data: {
              labels: ["Contract 1", "Contract 2", "Contract 3", "Contract 4", "Contract 5", "Contract 6"],
              datasets: [{
                  barPercentage: 1,
                  categoryPercentage: 0.5,
                  min: 0,
                  backgroundColor: [
                      '#ff6666',
                      '#f78e04',
                      'rgb(255, 205, 86)',
                      'rgb(75, 192, 192)',
                      '#6351ec',
                      'rgb(153, 102, 255)'
                  ],
                  data: [
                      [new Date(2020, 1), new Date(2020, 2)],
                      [new Date(2020, 2), new Date(2020, 12)],
                      [new Date(2020, 1), new Date(2020, 3)],
                      [new Date(2020, 3), new Date(2020, 10)],
                      [new Date(2020, 8), new Date(2020, 11)],
                      [new Date(2020, 1), new Date(2020, 5)],
                  ]
              }]
          },
          options: {
              legend: {
                  display: false,
              },
              scales: {
                  xAxes: [{
                      ticks: {
                          beginAtZero: false,
                          fontStyle: "normal",
                          fontFamily: "'Oxygen', sans-serif",
                          fontColor: '#6c75a8',
                          fontSize: 13,
                      },
                      stacked: true,
                  }],
                  yAxes: [{
                      ticks: {
                          beginAtZero: false,
                          fontStyle: "normal",
                          fontFamily: "'Oxygen', sans-serif",
                          fontColor: '#6c75a8',
                          fontSize: 13,
                      },
                      stacked: true,
                  }],
              },
              tooltips: {
                  fontFamily: "'Oxygen', sans-serif",
                  backgroundColor: 'rgba(0,0,0,0.3)',
                  caretSize: 5,
                  cornerRadius: 2,
                  xPadding: 10,
                  yPadding: 10,
                  titleFontStyle: 'normal',
                  bodyFontStyle: 'normal',
                  titleFontSize: 13,
                  bodyFontSize: 13
              }
          }
      });
  }
}