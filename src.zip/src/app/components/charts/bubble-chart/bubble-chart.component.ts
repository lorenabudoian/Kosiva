import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-bubble-chart',
    templateUrl: './bubble-chart.component.html',
    styleUrls: ['./bubble-chart.component.scss']
})
export class BubbleChartComponent implements AfterViewInit {

    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit(): void {

        var popCanvas = document.getElementById("popChart");

        chart.defaults.global.defaultFontFamily = "Lato";
        chart.defaults.global.defaultFontSize = 18;

        var options = {
            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 90,
                        fontStyle: "normal",
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        fontColor: '#6c75a8',
                        min: 0
                    },

                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.5,
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {
                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }
            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                fontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13,
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10
            }
        };

        var popData = {
            datasets: [{
                label: ['Deer Population'],
                data: [{
                        x: 0,
                        y: 100,
                        r: 5
                    },
                    {
                        x: 20,
                        y: 30,
                        r: 25
                    },
                    {
                        x: 28,
                        y: 75,
                        r: 6
                    },
                    {
                        x: 29,
                        y: 35,
                        r: 6
                    },
                    {
                        x: 30,
                        y: 50,
                        r: 8
                    }, ,
                    {
                        x: 32,
                        y: 70,
                        r: 8
                    },
                    {
                        x: 34,
                        y: 67,
                        r: 5
                    },
                    {
                        x: 36,
                        y: 37,
                        r: 5
                    },
                    {
                        x: 38,
                        y: 60,
                        r: 5
                    },
                    {
                        x: 40,
                        y: 60,
                        r: 2
                    },
                    {
                        x: 40,
                        y: 40,
                        r: 4
                    },
                    {
                        x: 40,
                        y: 80,
                        r: 6
                    },
                    {
                        x: 44,
                        y: 79,
                        r: 10
                    },
                    {
                        x: 45,
                        y: 29,
                        r: 3
                    },
                    {
                        x: 49,
                        y: 29,
                        r: 10
                    },
                    {
                        x: 54,
                        y: 27,
                        r: 5
                    },
                    {
                        x: 58,
                        y: 50,
                        r: 4
                    },
                    {
                        x: 60,
                        y: 30,
                        r: 4
                    },
                    {
                        x: 65,
                        y: 60,
                        r: 20
                    },
                    {
                        x: 65,
                        y: 80,
                        r: 2
                    },
                    {
                        x: 67,
                        y: 30,
                        r: 2
                    },
                    {
                        x: 70,
                        y: 20,
                        r: 5
                    },
                    {
                        x: 75,
                        y: 55,
                        r: 5
                    },
                    {
                        x: 80,
                        y: 80,
                        r: 30
                    },
                    {
                        x: 85,
                        y: 34,
                        r: 3
                    },
                    {
                        x: 88,
                        y: 60,
                        r: 6
                    },
                    {
                        x: 90,
                        y: 50,
                        r: 8
                    },
                    {
                        x: 100,
                        y: 0,
                        r: 10
                    }
                ],
                backgroundColor: [
                    "#bd4603",
                    "##bd4603",
                    "#ff6800",
                    "#ff6800",
                    "#ff6800",
                    "#ff6800",
                    "#ff8600",
                    "#ff8600",
                    "#ff8600",
                    "#ff8600",
                    "#ff8600",
                    "#ff9502",
                    "#ff9502",
                    "#ff9502",
                    "#ff9502",
                    "#ffad22",
                    "#ffad22",
                    "#ffad22",
                    "#ffad22",
                    "#ffad22",
                    "#ffb228",
                    "#ffb228",
                    "#ffb228",
                    "#ffcc3a",
                    "#ffcc3a",
                    "#ffcc3a",
                    "#ffcc3a",
                    "#ffcc3a",
                    "#ffcc3a",
                ],
                hoverBackgroundColor: "#000000",
                hoverBorderColor: "#9966FF",
                hoverBorderWidth: 5,
                hoverRadius: 5
            }]
        };

        var bubbleChart = new chart(popCanvas, {
            type: 'bubble',
            data: popData,
            options: options
        });

    }


}