import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-linear-chart',
    templateUrl: './linear-chart.component.html',
    styleUrls: ['./linear-chart.component.scss']
})
export class LinearChartComponent implements AfterViewInit {


    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit() {
        var earnings = this.chartElement.nativeElement.querySelector('#ks-chart-earnings')
        var chart_earnings = earnings.getContext('2d'),
            gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);

        gradient.addColorStop(0, '#ffa500ba');
        gradient.addColorStop(0.4, '#ffa5003b');
        gradient.addColorStop(1, ' transparent');


        var gradientStroke = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroke.addColorStop(0.3, "#685621");
        gradientStroke.addColorStop(0.5, "#685621");
        gradientStroke.addColorStop(0.9, "#685621");


        var data = {
            labels: ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''
            ],
            datasets: [{

                    label: 'Earnings',
                    borderColor: '#806504',
                    pointBorderColor: gradientStroke,
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 0.2,
                    borderWidth: 2,
                    data: [40, 41, 32, 30, 41, 40, 43, 68, 67, 62, 57, 61, 82, 89, 70, 80, 91, 92, 80, 91, 80, 93, 128, 127, 132, 127, 151, 152, 159, 140,
                        130, 131, 132, 130, 141, 140, 143, 128, 127, 132, 127, 151, 152, 159, 140, 130, 131, 132, 130, 141, 160, 163, 178, 177, 182, 187, 151, 152, 159, 140
                    ]
                }, {
                    label: 'Total Sales',
                    borderColor: '#3856a3',
                    pointBorderColor: gradientStroke,
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    backgroundColor: '#251b6b2b',
                    borderWidth: 2,
                    pointBorderWidth: 0,
                    data: [
                        130, 131, 132, 130, 141, 140, 143, 128, 127, 132, 127, 151, 152, 159, 140, 130, 131, 132, 130, 81, 70, 63, 78, 57, 62, 57, 41, 82, 89, 70,
                        41, 40, 43, 68, 67, 62, 57, 61, 82, 89, 70,
                        40, 41, 32, 30, 41, 40, 43, 68, 67, 62, 57, 61, 82, 89, 70, 80, 91, 92, 80, 91, 80, 93, 128, 127, 132, 127, 151, 152, 159, 140,
                        41, 40, 43, 68, 67, 62, 57, 61, 82, 89, 70,
                    ]
                },
                {
                    label: 'Expenses',
                    borderColor: '#251b6b',
                    pointBorderColor: gradientStroke,
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 0.1,
                    backgroundColor: '#2a196391',
                    borderWidth: 2,
                    data: [1, 1, 2, 2, 4, 4, 14, 25, 23, 27, 18, 21, 13, 23, 20, 20, 31, 22, 35, 40, 30, 23, 30, 27, 42, 27, 21, 38, 29, 22,
                        22, 25, 20, 10, 23, 20, 27, 22, 27, 21, 28, 29, 12, 13, 23, 20, 20, 21, 22, 25, 20, 10, 23, 20, 27, 22, 27, 21, 28, 29, 12,
                        20, 21, 22, 34, 21, 20, 23, 20, 21, 20, 20, 26, 27, 27, 20, 20, 26, 20, 20, 21, 20, 23, 28, 27, 22, 27, 21, 22, 29, 20
                    ]
                }
            ],

        };

        var options = {

            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        fontColor: '#6c75a8',
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 200,
                        min: 0,
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },

                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.5,
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.2
                }
            },
            legend: {

                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }

            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                fontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };


        var chartInstance = new chart(chart_earnings, {
            type: 'line',
            data: data,
            options: options
        });
    }


}