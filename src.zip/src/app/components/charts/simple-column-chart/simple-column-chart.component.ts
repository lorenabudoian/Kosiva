import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-simple-column-chart',
    templateUrl: './simple-column-chart.component.html',
    styleUrls: ['./simple-column-chart.component.scss']
})
export class SimpleColumnChartComponent implements AfterViewInit {

    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit(): void {

        var earnings = this.chartElement.nativeElement.querySelector('#simple-column-chart');
        var ctx = earnings.getContext('2d');


        var data = {
            labels: ["USA", "UK", "FR", "RO", "CN", "NZ", "SP", "PO", "LE", "ZK", "USA", "UK", "FR", "RO", "CN", "NZ", "SP", "PO", "LE", "ZK"],
            datasets: [{
                label: "All Sales",
                backgroundColor: "#7c13ff2e",
                borderColor: "#7c13ff",
                borderWidth: 2,
                hoverBackgroundColor: "rgba(255,99,132,0.4)",
                hoverBorderColor: "rgba(255,99,132,1)",
                data: [90, 78, 65, 54, 35, 50, 30, 15, 10, 35, 90, 78, 65, 54, 35, 50, 30, 15, 10, 35],
            }]
        };

        var options = {
            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontSize: 13,
                        fontColor: '#6c75a8',
                        fontFamily: "'Open Sans', sans-serif",
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 90,
                        fontStyle: "normal",
                        fontSize: 13,
                        fontColor: '#6c75a8',
                        fontFamily: "'Open Sans', sans-serif",
                        min: 0
                    },

                    gridLines: {
                        color: '#0d0827',
                        lineWidth: 0.5,
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {
                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }
            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                fontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };

        var myBarChart = new chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });

    }


}