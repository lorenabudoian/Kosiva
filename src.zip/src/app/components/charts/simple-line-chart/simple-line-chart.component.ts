import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-simple-line-chart',
    templateUrl: './simple-line-chart.component.html',
    styleUrls: ['./simple-line-chart.component.scss']
})
export class SimpleLineChartComponent implements AfterViewInit {


    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit() {
        var earnings = this.chartElement.nativeElement.querySelector('#simple-line-chart')
        var chart_earnings = earnings.getContext('2d'),
            gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);

        gradient.addColorStop(0, '#7b23f738');
        gradient.addColorStop(0.3, '#7b23f738');
        gradient.addColorStop(1, ' transparent');


        var gradientStroke = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroke.addColorStop(0.1, "#da00d6");
        gradientStroke.addColorStop(0.5, "#6f1ccb");
        gradientStroke.addColorStop(0.9, "#7143ff");


        var data = {
            labels: ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
            datasets: [{

                label: 'Earnings',
                borderColor: gradientStroke,
                pointBorderColor: gradientStroke,
                pointBackgroundColor: gradientStroke,
                backgroundColor: gradient,
                pointHoverBackgroundColor: gradientStroke,
                pointHoverBorderColor: gradientStroke,
                pointBorderWidth: 0.2,
                borderWidth: 2,
                data: [30, 40, 34, 39, 32, 50, 45, 39, 50, 64, 55,
                    60, 70, 63, 86, 97, 77, 91, 88, 98, 101, 127, 131, 152, 132, 122, 97
                ]
            }],

        };

        var options = {

            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 200,
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        min: 0,
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                    },

                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.5,
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {

                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }

            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                fontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };


        var chartInstance = new chart(chart_earnings, {
            type: 'line',
            data: data,
            options: options
        });
    }

}