import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-charts-with-background',
    templateUrl: './charts-with-background.component.html',
    styleUrls: ['./charts-with-background.component.scss']
})
export class ChartsWithBackgroundComponent implements AfterViewInit {

    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit() {
        var earnings = this.chartElement.nativeElement.querySelector('#charts-with-background')
        var chart_earnings = earnings.getContext('2d'),
            gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);

        gradient.addColorStop(0, '#c900bf8a');
        gradient.addColorStop(0.2, '#792cfe45');
        gradient.addColorStop(1, ' transparent');


        var gradientStroke = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroke.addColorStop(0.3, "#7041fd");
        gradientStroke.addColorStop(0.5, "#8c17d0");
        gradientStroke.addColorStop(0.9, "#7041fd");


        var gradientStroketwo = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroketwo.addColorStop(0.3, "#f66e57");
        gradientStroketwo.addColorStop(0.5, "#f66e57");
        gradientStroketwo.addColorStop(0.9, "#f66e57");


        var data = {
            labels: ['$1000', '$2000', '$4000', '$6000', '$8000', '$10.000', '$12.000', '$14.000', '$16.000', '$18.000', '$20.000', '$14.000', '$16.000', '$18.000', '$20.000'],
            datasets: [{
                label: 'Total Sales',
                borderColor: '#251b6b',
                pointBorderColor: gradientStroketwo,
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroketwo,
                pointHoverBorderColor: gradientStroketwo,
                backgroundColor: '#251b6b2b',
                borderWidth: 2,
                pointBorderWidth: 0,
                data: [3, 20, 12, 50, 29, 42, 24, 57, 23, 37, 65, 31, 10, 50, 3, 20, 12, 50, 29]

            }, {
                label: 'Earnings',
                borderColor: gradientStroke,
                pointBorderColor: gradientStroke,
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroke,
                pointHoverBorderColor: gradientStroke,
                pointBorderWidth: 0.2,
                backgroundColor: gradient,
                borderWidth: 2,
                data: [30, 70, 52, 110, 91, 120, 103, 138, 97, 162, 122, 171, 112, 140, 101, 162, 120, 171]
            }],

        };

        var options = {

            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 200,
                        min: 0,
                        fontStyle: "normal",
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        fontColor: '#6c75a8',
                    },

                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.6,
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {

                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }

            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                backgroundColor: 'rgba(0,0,0,0.3)',
                fontFamily: "'Oxygen', sans-serif",
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };


        var chartInstance = new chart(chart_earnings, {
            type: 'line',
            data: data,
            options: options
        });
    }


}