import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-triangle-chart',
    templateUrl: './triangle-chart.component.html',
    styleUrls: ['./triangle-chart.component.scss']
})
export class TriangleChartComponent implements AfterViewInit {


    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit() {
        var earnings = this.chartElement.nativeElement.querySelector('#triangle-chart')
        var chart_earnings = earnings.getContext('2d'),
            gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);

        gradient.addColorStop(0.1, '#9b00d573');
        gradient.addColorStop(0.14, '#28156e91');
        gradient.addColorStop(1, ' transparent');


        var gradientStroke = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroke.addColorStop(0.3, "#ec00dc");
        gradientStroke.addColorStop(0.5, "#8c17d0");
        gradientStroke.addColorStop(0.9, "#7041fd");


        var gradientStroketwo = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroketwo.addColorStop(0.3, "#f66e57");
        gradientStroketwo.addColorStop(0.5, "#f66e57");
        gradientStroketwo.addColorStop(0.9, "#f66e57");


        var data = {
            labels: ['10', '20', '40', '60', '80', '100', '120', '140', '160', '180', '200', '220',
                '240', '260', '280', '300', '320', '340', '360', '380',
                '400', '420', '440', '460', '480', '500', '520', '540'
            ],
            datasets: [{

                    label: 'Total Sales',
                    borderColor: '#251b6b',
                    pointBorderColor: gradientStroke,
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 0.1,
                    backgroundColor: '#261c6d52',
                    borderWidth: 2,

                    data: [8, 55, 26, 50, 31, 30, 0, 54, 25, 40, 28, 45, 26, 30, 21, 20, 13, 34, 25, 0, 36, 30, 21, 20, 13, 34, 25, 0]
                },
                {
                    label: 'Earnings',
                    borderColor: '#9a12d2',
                    pointBorderColor: '#9364b5',
                    pointBackgroundColor: '#9364b5',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 3,
                    backgroundColor: gradient,
                    borderWidth: 3,
                    data: [113, 130, 125, 150, 130, 152, 137, 113, 130, 120, 153, 140, 125, 137, 124, 152, 137, 153, 120, 110, , 125, 137, 124, 152, 137, 153, 120, 110]
                }
            ],

        };

        var options = {

            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        fontColor: '#6c75a8',
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 170,
                        min: 0,
                        fontStyle: "normal",
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                        fontColor: '#6c75a8',
                    },

                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.6,
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.1
                }
            },
            legend: {

                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }

            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };


        var chartInstance = new chart(chart_earnings, {
            type: 'line',
            data: data,
            options: options
        });
    }

}