import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
    selector: 'app-double-curve-chart',
    templateUrl: './double-curve-chart.component.html',
    styleUrls: ['./double-curve-chart.component.scss']
})
export class DoubleCurveChartComponent implements AfterViewInit {

    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor() {}

    ngAfterViewInit() {
        var earnings = this.chartElement.nativeElement.querySelector('#double-curve-chart')
        var chart_earnings = earnings.getContext('2d'),
            gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);

        gradient.addColorStop(0.2, '#9b00d573');
        gradient.addColorStop(0.4, '#28156e91');
        gradient.addColorStop(1, ' transparent');


        var gradientStroke = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroke.addColorStop(0.3, "#ec00dc");
        gradientStroke.addColorStop(0.5, "#8c17d0");
        gradientStroke.addColorStop(0.9, "#7041fd");


        var gradientStroketwo = chart_earnings.createLinearGradient(1300, 90, 100, 600);

        gradientStroketwo.addColorStop(0.3, "#f66e57");
        gradientStroketwo.addColorStop(0.5, "#f66e57");
        gradientStroketwo.addColorStop(0.9, "#f66e57");


        var data = {
            labels: ['$1000', '$2000', '$4000', '$6000', '$8000', '$10.000', '$12.000', '$14.000', '$16.000', '$18.000', '$20.000'],
            datasets: [{
                label: 'Total Sales',
                borderColor: '#251b6b',
                pointBorderColor: gradientStroketwo,
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroketwo,
                pointHoverBorderColor: gradientStroketwo,
                backgroundColor: '#251b6b2b',
                borderWidth: 3,
                pointBorderWidth: 0,

                data: [40, 61, 32, 60, 41, 70, 43, 78, 27, 82, 32, 21, 42]
            }, {
                label: 'Earnings',
                borderColor: gradientStroke,
                pointBorderColor: gradientStroke,
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroke,
                pointHoverBorderColor: gradientStroke,
                pointBorderWidth: 0.2,
                backgroundColor: gradient,
                borderWidth: 2,
                data: [3, 20, 52, 20, 69, 32, 54, 17, 53, 37, 65, 31, 40, 50]
            }],

        };

        var options = {

            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {

                xAxes: [{

                    gridLines: {
                        display: false
                    },
                    ticks: {
                        fontStyle: "normal",
                        fontFamily: "'Oxygen', sans-serif",
                        fontSize: 13,
                        fontColor: '#6c75a8',
                    },
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 100,
                        min: 0,
                        fontStyle: "normal",
                        fontColor: '#6c75a8',
                        fontSize: 13,
                        fontFamily: "'Oxygen', sans-serif",
                    },

                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.6,
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.4
                }
            },
            legend: {

                display: true,
                align: 'end',
                labels: {
                    fontColor: '#8b8fb3',
                    fontSize: 13,
                    fontFamily: "'Oxygen', sans-serif",
                }

            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                titleFontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10,
                titleFontStyle: 'normal',
                bodyFontStyle: 'normal',
                titleFontSize: 13,
                bodyFontSize: 13
            }
        };


        var chartInstance = new chart(chart_earnings, {
            type: 'line',
            data: data,
            options: options
        });
    }

}