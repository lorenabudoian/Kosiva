import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutStyleOneComponent } from './layout-style-one.component';

describe('LayoutStyleOneComponent', () => {
  let component: LayoutStyleOneComponent;
  let fixture: ComponentFixture<LayoutStyleOneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LayoutStyleOneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LayoutStyleOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
