import { Component, AfterViewInit, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-layout-style-one',
  templateUrl: './layout-style-one.component.html',
  styleUrls: ['./layout-style-one.component.scss']
})
export class LayoutStyleOneComponent implements AfterViewInit {
  constructor(){

  }
  @ViewChild(
    'angularIdElement', 
    {static:false}
  ) elementRef: ElementRef<any>;

  ngAfterViewInit(){
    this.elementRef.nativeElement.ownerDocument.body.style.background = '#f8e5e5';
 }
}