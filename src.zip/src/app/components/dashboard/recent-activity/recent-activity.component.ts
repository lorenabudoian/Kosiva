import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-recent-activity',
  templateUrl: './recent-activity.component.html',
  styleUrls: ['./recent-activity.component.scss']
})
export class RecentActivityComponent implements AfterViewInit{

  @ViewChild(
    'angularIdElement', 
    {static:false}
  ) chartElement: ElementRef<any>;
  
  ngAfterViewInit(){
 
      var speedCanvas = this.chartElement.nativeElement.querySelector("#speedChart");
      chart.defaults.global.defaultFontFamily = "nunito";
  
  
      var speedData = {
          labels: ["Jul", "Aug", "Sep", "Oct", "Nov"],
          datasets: [{
              label: "Activity",
              borderColor: "#e99502",
              pointBackgroundColor: "#e99502",
              pointBorderColor: "#e99502",
              pointHoverBackgroundColor: "#e99502",
              pointHoverBorderColor: "#e99502",
              data: [50, 40, 160, 140, 200],
          }]
      };
  
      var chartOptions = {
          responsive: true,
          maintainAspectRatio: true,
          animation: {
              easing: 'easeInOutQuad',
              duration: 520
          },
          scales: {
  
              xAxes: [{
  
                  gridLines: {
                      display: false
                  },
                  ticks: {
                      fontStyle: "normal",
                      fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                      fontSize: 13,
                      fontColor: '#6c75a8',
                  },
              }],
              yAxes: [{
                  ticks: {
                      beginAtZero: false,
                      max: 350,
                      fontStyle: "normal",
                      fontSize: 13,
                      fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                      fontColor: '#6c75a8',
                  },
  
                  gridLines: {
                      color: '#0d0827',
                      lineWidth: 1,
                  }
              }]
          },
          elements: {
              line: {
                  tension: 0.4
              }
          },
          legend: {
              display: false,
  
          },
          point: {
              backgroundColor: 'white'
          },
          tooltips: {
              titleFontFamily: 'nunito',
              backgroundColor: 'rgba(0,0,0,0.3)',
              titleFontColor: '#6c75a8',
              caretSize: 5,
              cornerRadius: 2,
              xPadding: 10,
              yPadding: 10
          }
      };

      var lineChart = new chart(speedCanvas, {
          type: 'line',
          data: speedData,
          options: chartOptions
      });
    
  }

  public name: string;
  public funds: number;
  public hour: number;
  public min: number;
  public currency: string;
  public money: number;
  public path: string;



  public activities = [
    {   name: 'Starbucks', funds: 12 , hour : 12, min:25, currency: '$', money :3.4535, path: '../../../../assets/img/96ed6e8dc71b6ff517e4bd50224fc06c.png' },
    {   name: 'H&M', funds: 345, hour : 11, min:10, currency: '$', money :4.35, path: '../../../../assets/img/HM-logo.jpg' },
    {   name: 'Zara', funds: 332, hour : 11, min:15, currency: '$', money :22.15, path: '../../../../assets/img/6701cfae3d4e6662bfdbddcf96934e20_750x750.jpg' }, 
    {   name: 'McDONALDS', funds: 345, hour : 19, min:40, currency: '$', money :15.5, path: '../../../../assets/img/1e06cec7e7162fc2db54c68fbf5f0d53.jpg' },
    {   name: 'Transport', funds: 332, hour : 11, min:15, currency: '$', money :92.2, path: '../../../../assets/img/bus.jpg' },
    {   name: 'Bank Transfer', funds: 345, hour : 19, min:40, currency: '$', money :35.4, path: '../../../../assets/img/pngtree-vector-bank-icon-png-image_708538.jpg' },
    {   name: 'Transport', funds: 332, hour : 11, min:15, currency: '$', money :15.34, path: '../../../../assets/img/bus.jpg' }, 
  ]

}
