import { Component,AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-diagram-completed-tasks',
  templateUrl: './diagram-completed-tasks.component.html',
  styleUrls: ['./diagram-completed-tasks.component.scss']
})
export class DiagramCompletedTasksComponent implements AfterViewInit{
  @ViewChild(
    'angularIdElement', 
    {static:false}
  ) chartElement: ElementRef<any>;

  constructor() { }

 ngAfterViewInit() {

      var daily_sales = this.chartElement.nativeElement.querySelector("#ks-completed-tasks");
  

      chart.defaults.global.defaultFontFamily = "nunito";
  
      var speedData = {
          labels: ["Jul", "Aug", "Sep", "Oct", "Nov"],
          datasets: [{
              label: "Tasks",
              borderColor: "#ffad1d",
              pointBackgroundColor: "#ffad1d",
              pointBorderColor: "#ffad1d",
              pointHoverBackgroundColor: "#ffad1d",
              pointHoverBorderColor: "#ffad1d",
              data: [50, 15, 40, 12, 40],
          }]
      };
  
      var chartOptions = {
          responsive: true,
          maintainAspectRatio: true,
          animation: {
              easing: 'easeInOutQuad',
              duration: 520
          },
          scales: {
  
              xAxes: [{
  
                  gridLines: {
                      display: false
                  },
                  ticks: {
                      fontStyle: "normal",
                      fontSize: 13,
                      fontFamily:  "'Oxygen', sans-serif",
                      fontColor: '#6c75a8',
                  },
              }],
              yAxes: [{
                  ticks: {
                      beginAtZero: false,
                      max: 80,
                      fontStyle: "normal",
                      fontSize: 13,
                      fontColor: '#6c75a8',
                      fontFamily:  "'Oxygen', sans-serif",
                  },
  
                  gridLines: {
                      color: '#0d0827',
                      lineWidth: 0.5,
                      fontFamily:  "'Oxygen', sans-serif",
                      fontSize:0.4,
                  }
              }]
          },
          elements: {
              line: {
                  tension: 0.4
              }
          },
          legend: {
              display: false,
  
          },
          point: {
              backgroundColor: 'white'
          },
          tooltips: {
              titleFontFamily: 'nunito',
              backgroundColor: 'rgba(0,0,0,0.3)',
              titleFontColor: '#9398b8',
              caretSize: 5,
              cornerRadius: 2,
              xPadding: 10,
              yPadding: 10
          }
      };
  
      var lineChart = new chart(daily_sales, {
          type: 'line',
          data: speedData,
          options: chartOptions
      });
  }

}
