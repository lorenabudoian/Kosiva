import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmation-number',
  templateUrl: './confirmation-number.component.html',
  styleUrls: ['./confirmation-number.component.scss']
})
export class ConfirmationNumberComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
