import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-amount',
  templateUrl: './select-amount.component.html',
  styleUrls: ['./select-amount.component.scss']
})
export class SelectAmountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
