import { Component,AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-diagram-daily-sales',
  templateUrl: './diagram-daily-sales.component.html',
  styleUrls: ['./diagram-daily-sales.component.scss']
})
export class DiagramDailySalesComponent implements AfterViewInit {

@ViewChild(
    'angularIdElement',
    {static:false}
  ) chartElement : ElementRef<any>;
 
  constructor() { }

  ngAfterViewInit() {


    var earnings = this.chartElement.nativeElement.querySelector('#ks-daily-sales')
    var ctx = earnings.getContext('2d');

      var data = {
          labels: ["USA", "UK", "FR", "RO", "CN", ],
          datasets: [{
              label: "sales",
              backgroundColor: "rgba(255,99,132,0.2)",
              borderColor: "rgba(255,99,132,1)",
              borderWidth: 2,
              hoverBackgroundColor: "rgba(255,99,132,0.4)",
              hoverBorderColor: "rgba(255,99,132,1)",
              data: [80, 70, 65, 42, 37],
          }]
      };
  
      var options = {
          responsive: true,
          maintainAspectRatio: true,
          animation: {
              easing: 'easeInOutQuad',
              duration: 520
          },
          scales: {
  
              xAxes: [{
  
                  gridLines: {
                      display: false
                  },
                  ticks: {
                      fontStyle: "normal",
                      fontSize: 13,
                      fontColor: '#6c75a8',
                      fontFamily:  "'Oxygen', sans-serif",
                  },
              }],
              yAxes: [{
                  ticks: {
                      beginAtZero: false,
                      max: 90,
                      fontStyle: "normal",
                      fontSize: 13,
                      fontColor: '#6c75a8',
                      fontFamily:  "'Oxygen', sans-serif",
                      min:30
                  },
  
                  gridLines: {
                      color: '#0d0827',
                      lineWidth: 0.5,
                      fontFamily:  "'Oxygen', sans-serif",
                      fontSize:0.4,
                  }
              }]
          },
          elements: {
              line: {
                  tension: 0.4
              }
          },
          legend: {
              display: false,
  
          },
          point: {
              backgroundColor: 'white'
          },
          tooltips: {
              titleFontFamily: 'nunito',
              backgroundColor: 'rgba(0,0,0,0.3)',
              titleFontColor: '#6c75a8',
              caretSize: 5,
              cornerRadius: 2,
              xPadding: 10,
              yPadding: 10
          }
      };
  
       
      var myBarChart = new chart(ctx, {
        type: 'bar',
        data: data,
        options: options
    });
    
  }

}
