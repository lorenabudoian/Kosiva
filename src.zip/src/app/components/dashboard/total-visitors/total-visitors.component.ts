import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-visitors',
  templateUrl: './total-visitors.component.html',
  styleUrls: ['./total-visitors.component.scss']
})
export class TotalVisitorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
