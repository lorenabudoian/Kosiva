import {
    Component,
    AfterViewInit,
    ViewChild,
    ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

import {MatDialog} from '@angular/material/dialog';
import { AlertDownloadCsvComponent } from '../alert-download-csv/alert-download-csv.component';



@Component({
    selector: 'app-diagram-price',
    templateUrl: './diagram-price.component.html',
    styleUrls: ['./diagram-price.component.scss']
})
export class DiagramPriceComponent implements AfterViewInit {

    @ViewChild(
        'angularIdElement', {
            static: false
        }
    ) chartElement: ElementRef < any > ;

    constructor(public dialog: MatDialog) {}

    openDialog() {
      const dialogRef = this.dialog.open(AlertDownloadCsvComponent);
  
      dialogRef.afterClosed().subscribe(result => {
        console.log(`Dialog result: ${result}`);
      });
    }

    ngAfterViewInit() {
        var earnings = this.chartElement.nativeElement.querySelector('#chart')
        var chart_earnings = earnings.getContext('2d'),
            gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);
    
        gradient.addColorStop(0, '#ffa500ba');
        gradient.addColorStop(0.2, '#ffa5003b');
        gradient.addColorStop(1, ' transparent');
  
  
        var gradientStroke = chart_earnings.createLinearGradient(980, 90, 100, 400);
        // gradientStroke.addColorStop(0, '#5a55d7');
    
        // gradientStroke.addColorStop(0.9, 'transparent');
        gradientStroke.addColorStop(0, "transparent");
        gradientStroke.addColorStop(0.1, "#602DC6");
        gradientStroke.addColorStop(0.5, "#602DC6");
        gradientStroke.addColorStop(0.8, "#6C51FF");
        gradientStroke.addColorStop(1, "transparent");
    
    
        var data = {
            labels: ['', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '',
                      '', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '','', '', '',''],
            datasets: [{
    
                label: 'Earnings',
                borderColor: gradientStroke,
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroke,
                pointHoverBorderColor: gradientStroke,
                backgroundColor: 'transparent',
                pointBorderWidth: 0,
                borderWidth:2,
                data: [40,41,32,30,41,40,43,68,67,62,57,61,82,89,70,80,91,92,80,91,80,93,128,127,132,127,151,152,159,140,
                       130,131,132,130,141,140,143,128,127,132,127,151,152,159,140,130,131,132,130,141,160,163,178,177,182,187,151,152,159,140]
            }, {
              label: 'Total Sales',
                borderColor: '#251b6b',
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroke,
                pointHoverBorderColor: gradientStroke,
                backgroundColor: 'transparent',
                borderWidth:2,
                pointBorderWidth: 0,
                data: [3,20,12,20,19,12,24,27,53,47,45,51,70,80,60,70,81,72,70,60,70,83,100,107,102,107,121,98,119,112,
                       120,111,112,104,121,110,123,110,91,90,100,116,97,97,90,100,96,120,120,121,130,113,148,157,162,167,141,132,149,120]
            },
            {
              label: 'Expenses',
                borderColor: '#251b6b',
                pointBorderColor: 'transparent',
                pointBackgroundColor: 'transparent',
                pointHoverBackgroundColor: gradientStroke,
                pointHoverBorderColor: gradientStroke,
                pointBorderWidth: 0,
                backgroundColor: 'transparent',
                borderWidth:2,
                data: [1,1,2,2,4,4,14,25,23,27,18,21,13,23,20,20,21,22,25,20,10,23,20,27,22,27,21,28,29,12,
                       20,21,22,34,21,20,23,20,21,20,20,26,27,27,20,20,26,20,20,21,20,23,28,27,22,27,21,22,29,20]
            }],
    
        };
        
        var options = {
    
            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {
    
                xAxes: [{
    
                    gridLines: {
                        display: false
                    },
    
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: false,
                        max: 210,
                        stepSize: 30,
                        min: 0,
                        fontStyle: "normal",
                        fontSize:13,
                        fontColor: '#6c75a8',
                        fontFamily: "'Oxygen', sans-serif",
                    },
    
                    gridLines: {
                        color: '#23206A',
                        lineWidth: 0.5,
                    }
                }]
            },
            elements: {
                line: {
                    tension: 0.2
                }
            },
            legend: {
                display: false,
                align: 'end',
                labels: {
                  fontColor: '#8b8fb3',
                  fontSize:13,
                  fontFamily: "'Oxygen', sans-serif",
              }
            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                titleFontFamily: "'Oxygen', sans-serif",
                backgroundColor: 'rgba(0,0,0,0.3)',
                titleFontColor: '#6c75a8',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10
            }
        };
        var chartInstance = new chart(chart_earnings, {
            type: 'line',
            data: data,
            options: options
        });
    }
}