
import {Component, ViewChild, ElementRef} from '@angular/core';

/**
 * @title List with selection
 */
@Component({
  selector: 'app-tasks-done',
  templateUrl: './tasks-done.component.html',
  styleUrls: ['./tasks-done.component.scss']
})
export class TasksDoneComponent {

  tasksDone:any;
  tasksDonechecked:any;
  
  @ViewChild(
    'angularIdElement', 
    {static:false}
  ) Element: ElementRef<any>;
  
  constructor(){

    this.tasksDone = [
      'Meeting with DR Department',
      'Book Flights to Seattle',
      'Buy Gifts for my Family',
      'Pay Bills',
      'Meeting with DR Department',
      'Book Flights to Seattle',
      'Buy Gifts for my Family',
    ];
  }
 
}



