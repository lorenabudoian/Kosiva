import { Component,AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-diagram-total-shipments',
  templateUrl: './diagram-total-shipments.component.html',
  styleUrls: ['./diagram-total-shipments.component.scss']
})
export class DiagramTotalShipmentsComponent implements AfterViewInit {

  @ViewChild(
      'angularIdElement', 
      {static:false}
    ) chartElement: ElementRef<any>;

  constructor() {}

  ngAfterViewInit() {
    var speedCanvas = this.chartElement.nativeElement.querySelector("#speedChart");
    

    var chartCanvas = speedCanvas.getContext('2d');
    var gradientStroke = chartCanvas.createLinearGradient(980, 90, 100, 400);

    gradientStroke.addColorStop(0.2, "#ff2775");
    gradientStroke.addColorStop(0.5, "#ff2775");
    gradientStroke.addColorStop(0.8, "#ff2775");

    var speedData = {
        labels: ["  Jul", "", "Sep", "", "Nov", "", "Jan","", "Mar"],
        datasets: [{
            label: "Shipments",
            borderColor: gradientStroke,
            borderDash: [5, 5],
            pointBackgroundColor: "#d90c73",
            pointBorderColor: "#d90c73",
            pointHoverBackgroundColor: "#d90c73",
            pointHoverBorderColor: "#d90c73",
            data: [0, 20, 75, 27, 15, 55,20, 40, 20],
        }]
    };
    
    var chartOptions = {
        responsive: true,
        maintainAspectRatio: true,
        animation: {
            easing: 'easeInOutQuad',
            duration: 520
        },
        scales: {
    
            xAxes: [{
    
                gridLines: {
                    display: false
                },
                ticks: {
                    fontStyle: "normal",
                    fontSize: 13,
                    fontColor: '#6c75a8',
                    fontFamily:  "'Oxygen', sans-serif"
                },
            }],
            yAxes: [{
                ticks: {
                beginAtZero: false,
                    max: 80,
                    fontStyle: "normal",
                    fontSize: 13,
                    fontColor: '#6c75a8',
                    fontFamily:  "'Oxygen', sans-serif"
                },
    
                gridLines: {
                    color: '#0d0827',
                    lineWidth: 0.4,
                    fontFamily:  "'Oxygen', sans-serif",
                    fontSize:0.4,
                }
            }]
        },
        elements: {
            line: {
                tension: 0.4
            }
        },
        legend: {
            display: false,
    
        },
        point: {
            backgroundColor: 'white'
        },
        tooltips: {
            titleFontFamily: "Hind Guntur",
            backgroundColor: 'rgba(0,0,0,0.3)',
            titleFontColor: '#6c75a8',
            caretSize: 5,
            cornerRadius: 2,
            xPadding: 10,
            yPadding: 10
        }
    };
    
    var lineChart = new chart(speedCanvas, {
        type: 'line',
        data: speedData,
        options: chartOptions
    });
    }
}
