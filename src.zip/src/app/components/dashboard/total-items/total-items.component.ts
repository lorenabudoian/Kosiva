import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-items',
  templateUrl: './total-items.component.html',
  styleUrls: ['./total-items.component.scss']
})
export class TotalItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
