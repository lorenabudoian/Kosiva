import { Component,  ViewChild, ElementRef, Output, EventEmitter, AfterViewInit} from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: [
    './dashboard.component.scss'
]
})
export class DashboardComponent implements AfterViewInit {

  @ViewChild('angularIdElement', 
  {static:false}
  ) loadElements: ElementRef<any>;

  @Output() 
  parentEvent = new EventEmitter<string>();
  childEvent = new EventEmitter<string>();


  parent : any;
  child:any;

  constructor() { 
  }

  ngAfterViewInit() {  

    var parent = this.loadElements.nativeElement.querySelector('.parent');
    var child = this.loadElements.nativeElement.querySelectorAll('.child');

    const sendMessage = ()  => {
      this.parentEvent.emit(parent);
      this.childEvent.emit(child);
    }
     sendMessage();
    
  }

}
