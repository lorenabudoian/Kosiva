import { Component,AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-fst-card',
  templateUrl: './fst-card.component.html',
  styleUrls: ['./fst-card.component.scss']
})
export class FstCardComponent implements AfterViewInit {
  @ViewChild(
    'angularIdElement', 
    {static:false}
  ) chartElement: ElementRef<any>;

  constructor() { }

 ngAfterViewInit() {

        var ctx = this.chartElement.nativeElement.querySelector("#myChart").getContext("2d");

        var gradient = ctx.createLinearGradient(0, 0, 0, 450);

        gradient.addColorStop(0.05, '#43259238');
        gradient.addColorStop(0.2, '#43259226');
        gradient.addColorStop(0.5, ' transparent');
        gradient.addColorStop(1, ' transparent');

        var gradientStroke = ctx.createLinearGradient(0, 0, 100, 0);
    
        gradientStroke.addColorStop(0, "white");
        gradientStroke.addColorStop(1, "white");

        ctx.canvas.parentNode.style.height = '308px';

        var data = {
            
            labels: ["Jan", "Feb", "Mar", "Apr", "May","Mar", "Apr", "May"],
            datasets: [
                {
                    label: 'Active',
                    borderColor: gradientStroke,
                    pointBorderColor: 'white',
                    pointBackgroundColor: 'white',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    backgroundColor:'transparent',
                    borderWidth: 2.5,
                    hitRadius :1,
                    pointStyle: 'line',
                    radius: 1,
                    data: [38, 50, 38,63,38,53,37,40]
                },               {
                    label: 'Inactive',
                    borderColor: '#774ae94a',
                    pointBorderColor: 'transparent',
                    pointBackgroundColor: 'transparent',
                    pointHoverBackgroundColor: gradientStroke,
                    pointHoverBorderColor: gradientStroke,
                    pointBorderWidth: 0.1,
                    backgroundColor: gradient,
                    borderWidth: 2,
                    data: [ 50, 38, 53, 38,53,38,40,37
                    ]
                }
            ],
        };
        var options = {

            responsive: true,
            maintainAspectRatio: true,
            animation: {
                easing: 'easeInOutQuad',
                duration: 520
            },
            scales: {
    
                xAxes: [{
                    display: true,
                    gridLines: {
                        display:false,
                        color: 'gray',
                        zeroLineColor: 'white'
                    },
                    ticks: {
                        display:false,
                        fontSize:13,
                        fontStyle: "bold",
                        fontFamily: "'Open Sans', sans-serif",
                        fontColor: '#b2a9ff',
                    },
                }],
                yAxes: [{
                    ticks: {
                        display:false,
                        max: 85,
                        fontSize:13,
                        min:10,
                        fontFamily: "'Open Sans', sans-serif",
                    },
                    gridLines: {
                        display:false,
                    }
 
                }]
            },
            elements: {
                line: {
                    tension: 0.5
                },
                point: {
                    radius:0
                }
            },
            legend: {
                display: true,
                position:'top',
                align: 'end',
                labels: {
                    fontColor: '#b2a9ff',
                    fontSize:13,
                    boxWidth: 6,
                    usePointStyle: true,
                    fontFamily: "'Open Sans', sans-serif",
                }
    
            },
            point: {
                backgroundColor: 'white'
            },
            tooltips: {
                titleFontFamily:  "'Open Sans', sans-serif",
                backgroundColor: 'white',
                titleFontColor: '#9398b8',
                caretSize: 5,
                cornerRadius: 2,
                xPadding: 10,
                yPadding: 10
            }
        };
        
        var myLineChart = new chart(ctx , {
            
         type: "line",
         data: data, 
         options:options
        });

        
}
}
