import { Component,  Input, AfterViewInit} from '@angular/core';

@Component({
  selector: 'app-alert-download-csv',
  templateUrl: './alert-download-csv.component.html',
  styleUrls: ['./alert-download-csv.component.scss']
})
export class AlertDownloadCsvComponent implements AfterViewInit {

  constructor() { }

  ngAfterViewInit(): void {
  }

}
