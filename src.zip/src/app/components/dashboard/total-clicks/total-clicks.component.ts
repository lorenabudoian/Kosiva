import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-clicks',
  templateUrl: './total-clicks.component.html',
  styleUrls: ['./total-clicks.component.scss']
})
export class TotalClicksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
