import {
  Component,
  AfterViewInit,
  ViewChild,
  ElementRef
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.scss']
})
export class InvoicesComponent implements AfterViewInit {
  @ViewChild(
      'angularIdElement', {
          static: false
      }
  ) chartElement: ElementRef < any > ;


  constructor() {}

  ngAfterViewInit() {
    var ctx = this.chartElement.nativeElement.querySelector('#myChart').getContext("2d");

    var gradient = ctx.createLinearGradient(200, 0, 0, 450);

    gradient.addColorStop(0, '#6848e7');
    gradient.addColorStop(0.2, '#251e6657');
    gradient.addColorStop(1, ' transparent');

      var data = {
          labels: ["Rejected", "", "Open", "", "Satisfied","", "Hired",""],
          datasets: [{
              backgroundColor: gradient,
              borderColor: '#6d67ffc9',
              pointBorderColor: 'white',
              pointBackgroundColor: 'rgb(88, 99, 184,0.7)',
              data: [80, 40, 80, 50, 80,30, 50, 30],
              pointStyle: 'point',
              pointRadius: 0,
              lineTension:0.4,
              pointHitRadius: 40,
          }],

      };
      
      var myChart = new chart(ctx, {
          type: 'radar',
          data: data,
          options: {
              scale: {
                  angleLines: {
                      display: true,
                      lineWidth: 3,
                      color: '#321c8c5e'
                  },
                  pointLabels: {
                      fontSize: 14,
                      fontStyle: '300',
                      fontColor: '#8c91b5',
                      fontFamily:  "'Mukta Vaani', sans-serif",
                  },
                  ticks: {
                      display: false,
                      maxTicksLimit: 5,
                      beginAtZero: true,
                      max: 90
                  },
                  gridLines: {
                      circular: true,
                      display: true,
                      color: '#321c8c5e',
                      lineWidth: 3
                  }
              },
              legend: {
                  display: false
              }
          },
      });

  }
}