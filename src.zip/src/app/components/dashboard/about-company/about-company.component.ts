import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-company',
  templateUrl: './about-company.component.html',
  styleUrls: ['./about-company.component.scss']
})
export class AboutCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  companyMembers = [{
    memberName: 'KS',
    backgroundColor: 'background-rose'
  },
  {
    memberName: 'TM',
    backgroundColor: 'background-green'
  },
  {
    memberName: 'OL',
    backgroundColor: 'background-secondary'
  },
  {
    memberName: 'TM',
    backgroundColor: 'background-lavender'
  }]
}
