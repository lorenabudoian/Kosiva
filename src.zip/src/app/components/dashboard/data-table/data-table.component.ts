import { AfterViewInit, Component, OnInit } from '@angular/core';

export interface Transaction {
  clientName: string;
  clientJob: string;
  cost: number;
  orderId: number;
  profit: number;
  city: string;
  status: string;
}

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {
  
  displayedColumns: string[] = ['position', 'clientName', 'profit', 'city', 'status', 'cost', 'orderId', 'download', 'removeItem'];

  transactions: Transaction[] = [
      {
          clientName: 'Victor Arnold',
          orderId: 192,
          clientJob: 'Human Resources Manager',
          cost: 26,
          profit: 3,
          city: 'Kibwezi',
          status: 'Pending'
      },
      {
          clientName: 'Golden Rossen',
          orderId: 132,
          clientJob: 'HR Business Partner',
          cost: 296,
          profit: 5,
          city: 'Litein',
          status: 'Confirmed'
      },
      {
          clientName: 'Victor Samuel',
          orderId: 772,
          clientJob: 'Tech Talents Recruiter',
          cost: 4,
          profit: 2,
          city: 'San Salvador',
          status: 'Pending'
      },
      {
          clientName: 'Harriet Scott',
          orderId: 612,
          clientJob: 'Talent Partner',
          cost: 5,
          profit: 10,
          city: 'Santa Ana',
          status: 'Pending'

      },
      {
          clientName: 'Golden Rossen',
          orderId: 236,
          clientJob: 'IT Recruiter at CGS',
          cost: 24,
          profit: 3,
          city: 'Delmas',
          status: 'Pending'

      },
      {
          clientName: 'Earl  Hopkins',
          orderId: 4162,
          clientJob: 'Finance Analyst',
          cost: 5,
          profit: 370,
          city: 'Gonaïves',
          status: 'Confirmed'

      },
  ];


  deleteItem(index: number) {
      var confirmDelete = confirm('Do you want to continue ?');

      if(confirmDelete){
        const transaction = this.transactions.filter((transaction, tIndex) => {
            return index !== tIndex
        });
        this.transactions = transaction;
      } else {
          return false;
      }

  }
  ngOnInit() {
  }

}
