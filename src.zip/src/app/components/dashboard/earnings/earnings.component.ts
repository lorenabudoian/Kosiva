import { Component,AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-earnings',
  templateUrl: './earnings.component.html',
  styleUrls: ['./earnings.component.scss']
})
export class EarningsComponent implements AfterViewInit {

  @ViewChild(
    'angularIdElement',
    {static:false}
  ) chartElement : ElementRef<any>;

  constructor() { }

  ngAfterViewInit() {
      var earnings = this.chartElement.nativeElement.querySelector('#ks-chart-earnings')
      var chart_earnings = earnings.getContext('2d'),
          gradient = chart_earnings.createLinearGradient(0, 0, 0, 450);
  
      gradient.addColorStop(0, '#585dca');
      gradient.addColorStop(0.4, ' #5863b800');
      gradient.addColorStop(1, ' transparent');
  
  
      var data = {
          labels: ['Jan', 'Feb', 'March', 'Apr', 'May', 'Jun', 'Jul'],
          datasets: [{
  
              label: 'Earnings',
              borderColor:gradient,
              backgroundColor: gradient,
              pointBackgroundColor: 'white',
              borderWidth: 3,
              data: [50, 25, 39, 20, 16, 60, 30]
          }],
  
      };
      
      var options = {
  
          responsive: true,
          maintainAspectRatio: true,
          animation: {
              easing: 'easeInOutQuad',
              duration: 520
          },
          scales: {
  
              xAxes: [{
  
                  gridLines: {
                      display: false
                  },
                  ticks: {
                      fontStyle: "normal",
                      fontFamily:  "'Oxygen', sans-serif",
                      fontColor: '#6c75a8',
                      fontSize:13,
                  },
              }],
              yAxes: [{
                  ticks: {
                      beginAtZero: false,
                      max: 70,
                      stepSize: 15,
                      fontFamily:  "'Oxygen', sans-serif",
                      fontStyle: "normal",
                      fontColor: '#6c75a8',
                      fontSize:13,
                  },
  
                  gridLines: {
                      color: '#23206A',
                      lineWidth: 0.5,
                  }
              }]
          },
          elements: {
              line: {
                  tension: 0.4
              }
          },
          legend: {
  
              display: false,
  
          },
          point: {
              backgroundColor: 'white'
          },
          tooltips: {
              titleFontFamily: 'nunito',
              backgroundColor: 'rgba(0,0,0,0.3)',
              titleFontColor: '#6c75a8',
              caretSize: 5,
              cornerRadius: 2,
              xPadding: 10,
              yPadding: 10
          }
      };
  
  
  
      var chartInstance = new chart(chart_earnings, {
          type: 'line',
          data: data,
          options: options
      });
  }

}
