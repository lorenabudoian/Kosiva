import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styled-maps',
  templateUrl: './styled-maps.component.html',
  styleUrls: ['./styled-maps.component.scss']
})
export class StyledMapsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
