import { Component,  ElementRef, AfterViewInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-third-map',
  templateUrl: './third-map.component.html',
  styleUrls: ['./third-map.component.scss']
})
export class ThirdMapComponent implements AfterViewInit {

  constructor() { }
  @ViewChild('mapContainer', {static: false}) gmap: ElementRef;
  
  map: google.maps.Map;

  lat = 40.689060;
  lng = -74.044636;

  coordinates = new google.maps.LatLng(this.lat, this.lng);

  mapOptions: google.maps.MapOptions = {
    center: this.coordinates,
    zoom: 6,
   };

   marker = new google.maps.Marker({
     position: this.coordinates,
     map: this.map,
     draggable: true,
     animation: google.maps.Animation.BOUNCE,
   });
   mapInitializer() {
    this.map = new google.maps.Map(this.gmap.nativeElement, {
     center: this.coordinates,
     zoom: 13,
     styles: [
      {
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#222343"
          },
          {
            "saturation": -5
          },
          {
            "lightness": -5
          }
        ]
      },
      {
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#666889"
          },
          {
            "weight": 1
          }
        ]
      },
      {
        "elementType": "labels.text.stroke",
        "stylers": [
          {
            "color": "#242f3e"
          },
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "administrative.locality",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#666889"
          }
        ]
      },
      {
        "featureType": "poi",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#6668a0"
          },
          {
            "saturation": -25
          },
          {
            "lightness": -10
          }
        ]
      },
      {
        "featureType": "poi.attraction",
        "elementType": "geometry",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "poi.business",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#1e223e"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "labels.text",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "poi.park",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#25284b"
          }
        ]
      },
      {
        "featureType": "road",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#9ca5b3"
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#25284b"
          },
          {
            "saturation": 5
          },
          {
            "lightness": -5
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "geometry.stroke",
        "stylers": [
          {
            "color": "#1e2241"
          }
        ]
      },
      {
        "featureType": "road.highway",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#666889"
          }
        ]
      },
      {
        "featureType": "transit",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#1e2241"
          },
          {
            "saturation": -15
          },
          {
            "visibility": "off"
          }
        ]
      },
      {
        "featureType": "transit.station",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#666889"
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
          {
            "color": "#1f2341"
          },
          {
            "saturation": -5
          },
          {
            "lightness": -20
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "labels.text.fill",
        "stylers": [
          {
            "color": "#515c6d"
          }
        ]
      },
      {
        "featureType": "water",
        "elementType": "labels.text.stroke",
        "stylers": [
          {
            "color": "#17263c"
          }
        ]
      }
    ]
    });
    this.marker.setMap(this.map);
  }

   ngAfterViewInit() {
     this.mapInitializer();
   }



}
