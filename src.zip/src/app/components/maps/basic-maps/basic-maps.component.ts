import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-maps',
  templateUrl: './basic-maps.component.html',
  styleUrls: ['./basic-maps.component.scss']
})
export class BasicMapsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
