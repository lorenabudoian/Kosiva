import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-standard-map',
  templateUrl: './standard-map.component.html',
  styleUrls: ['./standard-map.component.scss']
})
export class StandardMapComponent implements OnInit {

  zoom=9;
  constructor() { }

  ngOnInit(): void {
  }

}
