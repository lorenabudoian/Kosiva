import { ViewChild, Component, AfterViewInit, ElementRef } from '@angular/core';

@Component({
  selector: 'app-standard-styled-marker',
  templateUrl: './standard-styled-marker.component.html',
  styleUrls: ['./standard-styled-marker.component.scss']
})
export class StandardStyledMarkerComponent implements AfterViewInit{

  
   
  @ViewChild('mapContainer', {static: false}) gmap: ElementRef;
  
  map: google.maps.Map;

  lat = 51.678418;
  lng = 70.809007;

  coordinates = new google.maps.LatLng(this.lat, this.lng);

  mapOptions: google.maps.MapOptions = {
    center: this.coordinates,
    zoom: 8,
   };

   marker = new google.maps.Marker({
     position: this.coordinates,
     map: this.map,
     icon: "http://chart.apis.google.com/chart?chst=d_map_pin_letter_withshadow&chld=%E2%80%A2|58F7ED",
     animation: google.maps.Animation.DROP,
   });

   mapInitializer() {
    this.map = new google.maps.Map(this.gmap.nativeElement, {
     center: this.coordinates,
     zoom: 4
    });
    this.marker.setMap(this.map);
  }

   ngAfterViewInit() {
     this.mapInitializer();
   }

}

