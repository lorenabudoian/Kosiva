import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-standard-with-marker',
  templateUrl: './standard-with-marker.component.html',
  styleUrls: ['./standard-with-marker.component.scss']
})
export class StandardWithMarkerComponent implements AfterViewInit {
  
  @ViewChild('mapContainer', {static: false}) gmap: ElementRef;
  
  map: google.maps.Map;

  lat = 40.730610;
  lng = -73.935242;

  coordinates = new google.maps.LatLng(this.lat, this.lng);

  mapOptions: google.maps.MapOptions = {
    center: this.coordinates,
    zoom: 8,
   };

   marker = new google.maps.Marker({
     position: this.coordinates,
     map: this.map,
     animation: google.maps.Animation.DROP,
   });

   mapInitializer() {
    this.map = new google.maps.Map(this.gmap.nativeElement, {
     center: this.coordinates,
     zoom: 5
    });
    this.marker.setMap(this.map);
  }

   ngAfterViewInit() {
     this.mapInitializer();
   }
   
  }


