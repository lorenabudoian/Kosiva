import {
	Component,
	AfterViewInit,
	ViewChild,
	ElementRef,
  AfterContentInit
} from '@angular/core';
import * as chart from 'chart.js';

@Component({
  selector: 'app-subscribers-chart',
  templateUrl: './subscribers-chart.component.html',
  styleUrls: ['./subscribers-chart.component.scss']
})
export class SubscribersChartComponent implements AfterViewInit {

	@ViewChild(
		'angularIdElement', {
			static: false
		}
	) chartElement: ElementRef < any > ;

  subscribers = [
    { status: 'Unconfirmed', number: 224, percentage: '-70%'},
    { status: 'Bounced', number: 6434, percentage: '+20%'},
    { status: 'Spam complaints', number: 3224, percentage: '-60%'},
    { status: 'Active', number: 124, percentage: '-20%'},
  ]  

	constructor() {}

	ngAfterViewInit() {

    var earnings_two = this.chartElement.nativeElement.querySelector('#ks-chart-earnings-two')
		var chart_earnings_two = earnings_two.getContext('2d'),
			gradient = chart_earnings_two.createLinearGradient(0, 0, 0, 450);

		gradient.addColorStop(0, '#c900bf8a');
		gradient.addColorStop(0.2, '#792cfe45');
		gradient.addColorStop(1, ' transparent');


		var gradientStroke = chart_earnings_two.createLinearGradient(1300, 90, 100, 600);

		gradientStroke.addColorStop(0.3, "#7041fd");
		gradientStroke.addColorStop(0.5, "#8c17d0");
		gradientStroke.addColorStop(0.9, "#7041fd");


		var gradientStroketwo = chart_earnings_two.createLinearGradient(1300, 90, 100, 600);

		gradientStroketwo.addColorStop(0.3, "#f66e57");
		gradientStroketwo.addColorStop(0.5, "#f66e57");
		gradientStroketwo.addColorStop(0.9, "#f66e57");


		var data_two = {
			labels: ['', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
			datasets: [{
				label: 'Total Sales',
				borderColor: '#251b6b',
				pointBorderColor: gradientStroketwo,
				pointBackgroundColor: 'transparent',
				pointHoverBackgroundColor: gradientStroketwo,
				pointHoverBorderColor: gradientStroketwo,
				backgroundColor: '#251b6b2b',
				borderWidth: 2,
				pointBorderWidth: 0,
				data: [3, 20, 12, 50, 29, 42, 24, 57, 23, 37, 25, 31, 20, 40, 10, 20, 12, 50, 29]

			}, {
				label: 'Earnings',
				borderColor: gradientStroke,
				pointBorderColor: gradientStroke,
				pointBackgroundColor: 'transparent',
				pointHoverBackgroundColor: gradientStroke,
				pointHoverBorderColor: gradientStroke,
				pointBorderWidth: 0.2,
				backgroundColor: gradient,
				borderWidth: 2,
				data: [30, 70, 22, 60, 41, 70, 43, 68, 37, 72, 62, 91, 42, 120, 101, 72, 120, 21]
			}],

		};

		var options = {

			responsive: true,
			maintainAspectRatio: true,
			animation: {
				easing: 'easeInOutQuad',
				duration: 520
			},
			scales: {

				xAxes: [{

					gridLines: {
						display: false
					},
					ticks: {
						fontStyle: "normal",
						fontColor: '#9398b8',
						fontSize: 13,
						fontFamily: "'Oxygen', sans-serif",
					},
				}],
				yAxes: [{
					ticks: {
						beginAtZero: false,
            max: 150,
            stepSize: 15,
						min: 0,
						fontStyle: "normal",
						fontSize: 13,
						fontFamily: "'Oxygen', sans-serif",
						fontColor: '#9398b8',
					},

					gridLines: {
						color: '#23206A',
						lineWidth: 0.6,
					}
				}]
			},
			elements: {
				line: {
					tension: 0.4
				}
			},
			legend: {

				display: false,

			},
			point: {
				backgroundColor: 'white'
			},
			tooltips: {
				backgroundColor: 'rgba(0,0,0,0.3)',
				fontFamily: "'Oxygen', sans-serif",
				caretSize: 5,
				cornerRadius: 2,
				xPadding: 10,
				yPadding: 10,
				titleFontStyle: 'normal',
				bodyFontStyle: 'normal',
				titleFontSize: 13,
				bodyFontSize: 13
			}
		};

		var chartInstance = new chart(chart_earnings_two, {
			type: 'line',
			data: data_two,
			options: options
		});
  
  }
}

