import { Component } from '@angular/core';
import {
    MatTableDataSource
} from '@angular/material/table';

@Component({
    selector: 'app-subscribers-tabel',
    templateUrl: './subscribers-tabel.component.html',
    styleUrls: ['./subscribers-tabel.component.scss']
})
export class SubscribersTabelComponent {

    displayedColumns: string[] = ['position', 'clientName', 'email', 'city', 'date'];
    dataSource = new MatTableDataSource<Transaction>(transactions);

    applyFilter(event: Event) {
        const filterValue = (event.target as HTMLInputElement).value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
    }

}

export interface Transaction {
    clientName: string;
    email: string;
    date: string;
    city: string;
}

const transactions: Transaction[] = [{
    clientName: 'Victor Samuel',
    date: '1day',
    email: 'herriet@gmail.com',
    city: 'Malindi'
},
{
    clientName: 'Harriet Scott',
    date: '4days',
    email: 'victor@gmail.com',
    city: 'Santa Ana'
},
{
    clientName: 'Golden Rossen',
    date: '2days',
    email: 'harriet@gmail.com',
    city: 'Litein'
},
{
    clientName: 'Victor Arnold',
    date: '2days',
    email: 'allen.lore23@gmail.com',
    city: 'Kibwezi'
},
{
    clientName: 'Golden Rossen',
    date: '2days',
    email: 'harriet@gmail.com',
    city: 'Litein'
},
{
    clientName: 'Victor Arnold',
    date: '2days',
    email: 'allen.lore23@gmail.com',
    city: 'Kibwezi'
},
{
    clientName: 'Herriet Lorent',
    date: '3days',
    email: 'golen.as@gmail.com',
    city: 'San Salvador'
},
{
    clientName: 'Victor Arnold',
    date: '2days',
    email: 'allen.lore23@gmail.com',
    city: 'Kibwezi',
},
{
    clientName: 'Harriet Scott',
    date: '4days',
    email: 'victor@gmail.com',
    city: 'Santa Ana'
}
];
