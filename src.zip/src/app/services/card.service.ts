import { EventEmitter} from '@angular/core';
import { Card } from '../shared/card.model';

export class CardService {

  AddCard =  new EventEmitter < Card[] > ();
  constructor() {}

  private cards: Card[] = [
    new Card('Ludmila Bakil', 8385, 42342, 12, 2023, 'Visa Card',),
    new Card('Vera Lokidna', 6335, 26342, 10, 2029, 'Master Card',),
    new Card('Alvaro Novo', 2347, 42342, 10,  2025,'Master Card',),
  ];

  getCards(){
    return this.cards.slice();
  }
  addCard(card: Card) {
    this.cards.push(card);
    this.AddCard.emit(this.cards.slice())
  }
}

    
