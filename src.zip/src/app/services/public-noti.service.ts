import { Injectable } from '@angular/core';
import { NotificationsModel } from '../shared/trigger-notifications.model';
import { Observable } from 'rxjs';
import { of } from 'rxjs';

@Injectable()

export class AppPublicNotifications {

    private notice: NotificationsModel[] = [
        new NotificationsModel('warning', 'Opps, there was a problem saving your changes.'),
        new NotificationsModel('error', 'Your Panel is out of date. <a href="#" style="text-decoration:underline;"> Update</a>'),
        new NotificationsModel('success', 'Your changes have been saved.')
    ];
    private noticeData: NotificationsModel;
    constructor() {}

    public triggerNotice( notice: NotificationsModel ) {
        console.log('action triggered');
        this.noticeData = notice;
        this.showNotice();
    }

    public showNotice(): Observable<NotificationsModel> {
        return of( this.noticeData );
    }

    getNotifications(){
        return  this.notice.slice();
    }
}
  