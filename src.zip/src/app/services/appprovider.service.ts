import { Injectable } from '@angular/core';

@Injectable()

export class AppProviderService {

  public sidebar: any = {
    visible: true
  };


  constructor() {}


  setPageType( section:string ) {

    switch ( section ) {

      case '404':
        this.sidebar.visible = false;
        return;
      case 'login':
        this.sidebar.visible = false;
        return;
      default:
        this.sidebar.visible = true;
        return
    }
  }
}
