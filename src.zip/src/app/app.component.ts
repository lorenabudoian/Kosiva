import { Component, OnInit} from '@angular/core';
import { AppProviderService } from'./services/appprovider.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: [
    `./app.component.scss`  
  ],
})
export class AppComponent implements OnInit{

  constructor( 
    public service: AppProviderService,
    private translate: TranslateService
  ){ translate.setDefaultLang('en'); }

  ngOnInit() { 
  }

}
