import { Component,ViewChild, ElementRef, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-noti-trigger',
  templateUrl: './noti-trigger.component.html',
  styleUrls: ['./noti-trigger.component.scss']
})
export class NotiTriggerComponent implements AfterViewInit {

  @ViewChild('notiTrigger', {
    static: false
   }, ) notiElement: ElementRef < any > ;

public  notice = {
  
  type: 'error' || 'success' || 'warning',
  message : [
    {
      text: 'Opps, there was a problem saving your changes.',
      type: 'warning'
    },
    {
        text: 'Your Panel is out of date. <a href="#" style="text-decoration:underline;"> Update</a>',
        type: 'error'
    },
    {
      text: 'Your changes have been saved.',
      type: 'success'
    }
  ]
}

constructor() {}

ngAfterViewInit() {
}

trigger() {
    var randomNoticeIndex = Math.floor(Math.random() * (this.notice.message.length));
    this.triggerNotice(this.notice.message[ randomNoticeIndex ]);
    this.triggerUp();
    this.translateUp();
}

triggerNotice(notice) {
    var bannerColor = '';
    if (notice.type === 'error') {
        bannerColor = "danger";
    } else if (notice.type === 'success') {
        bannerColor = 'primary';
    } else if (notice.type === 'warning') {
        bannerColor = 'warning';
    }

    var noticeBanner = document.createElement('div');
    noticeBanner.classList.add('notice-banner');
    var closeIcon= document.createElement('span');

    closeIcon.classList.add('close');
    noticeBanner.classList.add(bannerColor);    
    noticeBanner.innerHTML = notice.text;
    noticeBanner.appendChild(closeIcon);

    this.notiElement.nativeElement.querySelector('#notiContainer').appendChild(noticeBanner);
    this.onClickClose();
}

triggerUp() {
    var container = document.querySelector("#notiContainer");

    var noticeItems = container.querySelectorAll('.notice-banner');
    for (let i = noticeItems.length - 1; i >= 0; i--) {
        if (noticeItems.length >= 4) {
            if (i == 0) {
                noticeItems[0].classList.add('fadeout');
                setTimeout(() => {
                    noticeItems[0].remove();
                }, 200);
            }
        }
        setTimeout(() => {
            noticeItems[i].classList.add('fadeoutAll');
            setTimeout(() => {
                noticeItems[i].remove();
            }, 200);
        }, 9000);
    }
}

onClickClose() {
    var closeItem = this.notiElement.nativeElement.querySelectorAll('.close');

    document.querySelectorAll(".notice-banner").forEach( (item) => {
        item.querySelector('.close').addEventListener( 'click', () => {
            setTimeout(() => {
                item.remove();
            });
             this.translateUp();
        })
    });

}


translateUp() {
    const container = document.querySelector("#notiContainer");
    const noticeItems: any = container.querySelectorAll('.notice-banner');

    for (let i = 0; i <=noticeItems.length -1 ; i++) {

        if ( i != noticeItems.length - 1) {
            if ( i == noticeItems.length - 2) {
                const translateTop = (-60);
                noticeItems[i].style.transform = `translateY(${ translateTop }px)`;   
            } else if ( i == noticeItems.length - 3) {
                const translateTop = (-120);
                noticeItems[i].style.transform = `translateY(${ translateTop }px)`;   
            }
        }
    }
  }
}
  

  


