import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
    selector: 'app-logout-modal',
    templateUrl: './logout-modal.component.html',
    styleUrls: ['./long-bar.component.scss']
  })
export class LogoutModal {

    _routerSubscription: any;
    
    constructor(public dialogRef: MatDialogRef<LogoutModal>, public router: Router) { }

    LogOut(event) {
        this.router.navigate(['./login2'])
        .then(() => 
          this.dialogRef.close()
        )
    }

    ngOnInit() {
    }

}

@Component({
    selector: 'app-settings',
    templateUrl: './settings.component.html',
    styleUrls: ['./long-bar.component.scss']
  })
export class Settings {}

@Component({
    selector: 'app-long-bar',
    templateUrl: './long-bar.component.html',
    styleUrls: ['./long-bar.component.scss']
})

export class LongBarComponent {

    constructor(public dialog: MatDialog) {}

    openDialog() {
        const dialogRefLogout = this.dialog.open(LogoutModal);
    }

    openDialogSettings() {
        const dialogRefSettings = this.dialog.open(Settings);
    }

    languages = ['Akan', 'Alabama ', 'বাংলা', 'Босански', 'Català', ' Bisaya', 'Chahta Anumpa', ' Dansk', 'Dalmål', 'Dômarî', 'Deutsch', 'Fala', 'Italiano', 'English', 'Romanian', 'Suomi',
        'Norwegian', 'Persian', 'Polish', 'Thai', 'Spanish', 'Malay', 'Javanese', 'Japanese', 'Galician', 'French', 'Finnish'
    ];

    messageItem: any[] = [{
            personName: 'Joan Baez',
            timeSent: '21m ago',
            message: 'Hi Jack, How are you?!',
            source: '../../../assets/img/austin-distel-7uoMmzPd2JA-unsplash.jpg'
        },
        {
            personName: 'Max Ken',
            timeSent: '28m ago',
            message: 'See when your contacts type messages',
            source: '../../../assets/img/iler-stoe-iEAvKBfqD8c-unsplash.jpg'
        },
        {
            personName: 'Nick Drake',
            timeSent: '28m ago',
            message: 'Messages has the perfect GIF or sticker  for ...',
            source: '../../../assets/img/austin-distel-va_Opp86kfQ-unsplash.jpg'
        },
        {
            personName: 'Rick Wakeman',
            timeSent: '52m ago',
            message: 'See useful information from businesses  and get more done, all from your Messages app.',
            source: '../../../assets/img/marius-ciocirlan-vMV6r4VRhJ8-unsplash.jpg'
        },
        {
            personName: 'Nelo Kermin',
            timeSent: '21h ago',
            message: 'See when your contacts type messages',
            source: '../../../assets/img/gregory-hayes-Ss82hR_QRnw-unsplash.jpg'
        },
        {
            personName: 'Nick Drake',
            timeSent: '28m ago',
            message: 'Messages has the perfect GIF or sticker  for ...',
            source: '../../../assets/img/austin-distel-va_Opp86kfQ-unsplash.jpg'
        },
        {
            personName: 'Rick Wakeman',
            timeSent: '52m ago',
            message: 'See useful information from businesses  and get more done, all from your Messages app.',
            source: '../../../assets/img/marius-ciocirlan-vMV6r4VRhJ8-unsplash.jpg'
        },
        {
            personName: 'Max Ken',
            timeSent: '28m ago',
            message: 'See when your contacts type messages',
            source: '../../../assets/img/iler-stoe-iEAvKBfqD8c-unsplash.jpg'
        },
        {
            personName: 'Nick Drake',
            timeSent: '28m ago',
            message: 'Messages has the perfect GIF or sticker  for ...',
            source: '../../../assets/img/austin-distel-va_Opp86kfQ-unsplash.jpg'
        }
    ]


    ngOnInit() {}

}