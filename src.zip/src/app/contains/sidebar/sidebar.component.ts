import {
  Component,
  AfterViewInit,
  ViewChild,
  ElementRef
} from '@angular/core';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styles: [
      './sidebar.component.scss',
  ]
})

export class SidebarComponent implements AfterViewInit {


  constructor() {}

  @ViewChild(
      'angularIdElement', {
          static: false
      }
  ) clickEvent: ElementRef < any > ;


  ngAfterViewInit() {

      var menu_section = this.clickEvent.nativeElement.querySelectorAll(".ks-menu-section"),
          panel_elements = this.clickEvent.nativeElement.querySelectorAll(".off");
      var i, j;

      function removeClass() {
          for (i = 0; i < menu_section.length; i++) {

              for (j = 0; j < panel_elements.length; j++) {
                  menu_section[i].classList.remove("active-class");
                  panel_elements[j].style.maxHeight = null;
                  panel_elements[j].style.margin = "0px";
              }
          }
      }
      var isOpen = false;

      function get_section() {

          for (i = 0; i < menu_section.length; i++) {

              menu_section[i].addEventListener("click", function() {
                  isOpen = !isOpen;

                  var panel = this.querySelector(".off");

                  for (j = 0; j < panel_elements.length; j++) {

                      if (this.className.indexOf("active-class") == -1) {
                          removeClass();
                          if (panel != null) {
                              panel.style.maxHeight = panel.scrollHeight + "px";
                              panel.style.margin = "15px 0px 0px 0px";
                          } 
                          this.classList.add("active-class");

                      } else  {
                          if(isOpen) {
                              panel.style.maxHeight = panel.scrollHeight + "px";
                              panel.style.margin = "15px 0px 0px 0px";
                          } else{
                            panel.style.maxHeight = null;
                            panel.style.margin = "0px";
                          }
                        
                      }
                  }


              });
          }
      }
      get_section();

  }
}