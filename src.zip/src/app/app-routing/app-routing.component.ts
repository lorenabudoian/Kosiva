import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-routing',
  templateUrl: './app-routing.component.html',
})
export class AppRoutingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
