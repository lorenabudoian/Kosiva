import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './../components/dashboard/dashboard.component';
import { FormElementsComponent } from './../components/forms/form-elements/form-elements.component';
import { MaterialDesignComponent } from './../components/icons/material-design/material-design.component';
import { FormLayoutComponent } from './../components/forms/form-layout/form-layout.component';
import { StyledMapsComponent } from './../components/maps/styled-maps/styled-maps.component';
import { BasicMapsComponent } from './../components/maps/basic-maps/basic-maps.component';
import { FontAwesomeComponent } from './../components/icons/font-awesome/font-awesome.component';
import { ButtonsComponent } from './../components/ui-elements/buttons/buttons.component';
import { ColorsComponent } from './../components/ui-elements/colors/colors.component';
import { ImagesComponent } from './../components/ui-elements/images/images.component';
import { LoadersComponent } from './../components/ui-elements/loaders/loaders.component';
import { BadgesComponent } from './../components/ui-elements/badges/badges.component';
import { TabsComponent } from './../components/ui-elements/tabs/tabs.component';
import { TablesComponent } from './../components/tables/tables.component';
import { SlidersComponent } from './../components/ui-elements/sliders/sliders.component';
import { SlidesComponent } from './../components/ui-elements/slides/slides.component';
import { ProgressBarsComponent } from './../components/ui-elements/progress-bars/progress-bars.component';
import { DialogComponent } from './../components/ui-elements/dialog/dialog.component';
import { StepperComponent } from '../components/stepper/stepper.component';
import { ExpansionPanelComponent } from './../components/ui-elements/expansion-panel/expansion-panel.component';
import { ChartsComponent } from './../components/charts/charts.component';
import { ErrorPageStyleOneComponent } from './../components/error-pages/error-page-style-one/error-page-style-one.component';
import { ErrorPageStyleTwoComponent } from './../components/error-pages/error-page-style-two/error-page-style-two.component';
import { ErrorPageStyleThreeComponent } from './../components/error-pages/error-page-style-three/error-page-style-three.component';
import { SidebarComponent } from '../contains/sidebar/sidebar.component';
import { PriceListComponent } from '../components/price-list/price-list.component';
import { LoginMainPageComponent } from '../components/pages/login-modals/login-main-page/login-main-page.component';
import { LoginPageTwoComponent } from '../components/pages/login-modals/login-page-two/login-page-two.component';
import { LoginPageThreeComponent } from '../components/pages/login-modals/login-page-three/login-page-three.component';
import { CalendarComponent } from '../components/calendar/calendar.component';
import { MyWalletComponent } from '../components/my-wallet/my-wallet.component';
import { SubscribersComponent } from '../components/subscribers/subscribers.component';
import { NotificationsComponent } from '../components/ui-elements/notifications/notifications.component';



const routes: Routes = [
  {
    path: '', component: LoginMainPageComponent
  },
  {
    path: 'dashboard', component: DashboardComponent
  },
  {
    path: 'login2', component: LoginPageTwoComponent
  },
  {
    path: 'login3', component: LoginPageThreeComponent
  },
  {
    path: 'form-elements', component: FormElementsComponent
  },
  {
    path: 'form-layout', component: FormLayoutComponent
  },
  {
    path: 'styled-maps', component: StyledMapsComponent
  },
  {
    path: 'basic-maps', component: BasicMapsComponent
  },
  {
    path: 'material-design', component: MaterialDesignComponent
  },
  {
    path: 'font-awesome', component: FontAwesomeComponent
  },
  {
    path: 'buttons', component: ButtonsComponent
  },
  {
    path: 'colors', component: ColorsComponent
  },
  {
    path: 'sidebar', component: SidebarComponent
  },
  {
    path: 'images', component: ImagesComponent
  },
  {
    path: 'loaders', component: LoadersComponent
  },
   {
    path: 'badges', component: BadgesComponent
  },
  {
    path: 'notifications-component', component: NotificationsComponent
  },
  {
    path: 'tabs', component: TabsComponent
  },
  {
    path: 'tables', component: TablesComponent
  },
  {
    path: 'sliders', component: SlidersComponent
  },
  {
    path: 'slides', component: SlidesComponent
  },
  {
    path: 'progress-bars', component: ProgressBarsComponent
  },
  {
    path: 'expansion-panel', component: ExpansionPanelComponent
  },
  {
    path: 'stepper', component: StepperComponent
  },
  {
    path: 'charts', component: ChartsComponent
  },
  {
    path: 'calendar', component: CalendarComponent
  },
  {
    path: 'dialog', component: DialogComponent
  },
  {
    path: 'error-page-style-one', component: ErrorPageStyleOneComponent
  },
  {
    path: 'error-page-style-two', component: ErrorPageStyleTwoComponent
  }, 
  {
    path: 'error-page-style-three', component: ErrorPageStyleThreeComponent
  },
  {
    path: 'price-list', component: PriceListComponent
  },
  {
    path: 'my-wallet', component: MyWalletComponent
  },
  {
    path: 'subscribers', component: SubscribersComponent
  },
  { 
    path: '**', redirectTo: 'error-page-style-three' 
  }


];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
export const routingComponents = [
   DashboardComponent,
   FormLayoutComponent,
   DialogComponent,
   PriceListComponent,
   ChartsComponent,
   FormElementsComponent,
   NotificationsComponent,
   SlidesComponent,
   StyledMapsComponent,
   BasicMapsComponent,
   FontAwesomeComponent,
   MaterialDesignComponent,
   ButtonsComponent,
   ColorsComponent,
   ImagesComponent,
   LoadersComponent,
   BadgesComponent,
   TabsComponent,
   TablesComponent,
   SlidersComponent,
   ProgressBarsComponent,
   ExpansionPanelComponent,
   StepperComponent,
   LoginMainPageComponent,
   LoginPageTwoComponent,
   SubscribersComponent,
   LoginPageThreeComponent,
   ErrorPageStyleOneComponent,
   ErrorPageStyleTwoComponent,
   ErrorPageStyleThreeComponent,
   CalendarComponent
  ]
