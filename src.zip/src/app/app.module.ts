import { BrowserModule} from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatListModule } from '@angular/material/list';
import { AppRoutingModule,routingComponents } from './app-routing/app-routing.module';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { FullCalendarModule } from '@fullcalendar/angular'; 
import { GoogleChartsModule } from 'angular-google-charts';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FlatpickrModule } from 'angularx-flatpickr';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { GoogleMapsModule } from '@angular/google-maps';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatBadgeModule } from '@angular/material/badge';
import { MatTabsModule} from '@angular/material/tabs';
import { MatRippleModule} from '@angular/material/core';
import { MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatMenuModule} from '@angular/material/menu';
import { MatTooltipModule, MatTooltip} from '@angular/material/tooltip';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSliderModule } from '@angular/material/slider';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatStepperModule } from '@angular/material/stepper';
import { MatChipsModule } from '@angular/material/chips';
import { HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { AppComponent } from './app.component';
import { SidebarComponent } from './contains/sidebar/sidebar.component';
import { LongBarComponent, LogoutModal, Settings } from './contains/long-bar/long-bar.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { FstCardComponent } from './components/dashboard/fst-card/fst-card.component';
import { InvoicesComponent } from './components/dashboard/invoices/invoices.component';
import { MatSelectModule } from '@angular/material/select';
import { WeatherComponent } from './components/dashboard/weather/weather.component';
import { DataTableComponent } from './components/dashboard/data-table/data-table.component';
import { DiagramPriceComponent } from './components/dashboard/diagram-price/diagram-price.component';
import { DiagramDailySalesComponent } from './components/dashboard/diagram-daily-sales/diagram-daily-sales.component';
import { DiagramCompletedTasksComponent } from './components/dashboard/diagram-completed-tasks/diagram-completed-tasks.component';
import { DiagramTotalShipmentsComponent } from './components/dashboard/diagram-total-shipments/diagram-total-shipments.component';
import { EarningsComponent } from './components/dashboard/earnings/earnings.component';
import { CurrentBalanceComponent } from './components/dashboard/current-balance/current-balance.component';
import { WithdrawMoneyComponent } from './components/dashboard/withdraw-money/withdraw-money.component';
import { SelectAmountComponent } from './components/dashboard/withdraw-money/select-amount/select-amount.component';
import { ConfirmationNumberComponent } from './components/dashboard/withdraw-money/confirmation-number/confirmation-number.component';
import { AppRoutingComponent} from './app-routing/app-routing.component';
import { AboutCompanyComponent } from './components/dashboard/about-company/about-company.component';
import { TotalVisitorsComponent } from './components/dashboard/total-visitors/total-visitors.component';
import { TotalClicksComponent } from './components/dashboard/total-clicks/total-clicks.component';
import { TotalItemsComponent } from './components/dashboard/total-items/total-items.component';
import { TasksDoneComponent } from './components/dashboard/tasks-done/tasks-done.component';
import { RecentActivityComponent } from './components/dashboard/recent-activity/recent-activity.component';
import { FormElementsComponent } from './components/forms/form-elements/form-elements.component';
import { FormLayoutComponent } from './components/forms/form-layout/form-layout.component';
import { FormStyleOneComponent } from './components/forms/form-layout/form-style-one/form-style-one.component';
import { FormStyleTwoComponent } from './components/forms/form-layout/form-style-two/form-style-two.component';
import { TextAreaComponent } from './components/forms/form-elements/text-area/text-area.component';
import { CheckboxesComponent } from './components/forms/form-elements/wrapper-container/checkboxes/checkboxes.component';
import { TextAreaStyleOneComponent } from './components/forms/form-elements/text-area/text-area-style-one/text-area-style-one.component';
import { TextAreaStyleTwoComponent } from './components/forms/form-elements/text-area/text-area-style-two/text-area-style-two.component';
import { TextAreaStyleThreeComponent } from './components/forms/form-elements/text-area/text-area-style-three/text-area-style-three.component';
import { SmallTextAreaComponent } from './components/forms/form-elements/text-area/text-area-style-two/small-text-area/small-text-area.component';
import { MediumTextAreaComponent } from './components/forms/form-elements/text-area/text-area-style-two/medium-text-area/medium-text-area.component';
import { LargeTextAreaComponent } from './components/forms/form-elements/text-area/text-area-style-two/large-text-area/large-text-area.component';
import { TextAreaFocusOneComponent } from './components/forms/form-elements/text-area/text-area-style-one/text-area-focus-one/text-area-focus-one.component';
import { TextAreaFocusTwoComponent } from './components/forms/form-elements/text-area/text-area-style-one/text-area-focus-two/text-area-focus-two.component';
import { TextAreaDottedOneComponent } from './components/forms/form-elements/text-area/text-area-style-three/text-area-dotted-one/text-area-dotted-one.component';
import { TextAreaDottedTwoComponent } from './components/forms/form-elements/text-area/text-area-style-three/text-area-dotted-two/text-area-dotted-two.component';
import { TextAreaDottedThreeComponent } from './components/forms/form-elements/text-area/text-area-style-three/text-area-dotted-three/text-area-dotted-three.component';
import { WrapperContainerComponent } from './components/forms/form-elements/wrapper-container/wrapper-container.component';
import { FileBrowserComponent } from './components/forms/form-elements/wrapper-container/file-browser/file-browser.component';
import { FileBrowserStyleTwoComponent } from './components/forms/form-elements/wrapper-container/file-browser/file-browser-style-two/file-browser-style-two.component';
import { FileBrowserStyleOneComponent } from './components/forms/form-elements/wrapper-container/file-browser/file-browser-style-one/file-browser-style-one.component';
import { FirstCheckboxComponent } from './components/forms/form-elements/wrapper-container/checkboxes/first-checkbox/first-checkbox.component';
import { SecondCheckboxComponent } from './components/forms/form-elements/wrapper-container/checkboxes/second-checkbox/second-checkbox.component';
import { ThirdCheckboxComponent } from './components/forms/form-elements/wrapper-container/checkboxes/third-checkbox/third-checkbox.component';
import { FourthCheckboxComponent } from './components/forms/form-elements/wrapper-container/checkboxes/fourth-checkbox/fourth-checkbox.component';
import { FifthCheckboxComponent } from './components/forms/form-elements/wrapper-container/checkboxes/fifth-checkbox/fifth-checkbox.component';
import { WrapperSecondContainerComponent } from './components/forms/form-elements/wrapper-second-container/wrapper-second-container.component';
import { SubmitButtonComponent } from './components/forms/form-elements/wrapper-second-container/submit-button/submit-button.component';
import { DatePickerComponent } from './components/forms/form-elements/wrapper-second-container/date-picker/date-picker.component';
import { MatNativeDateModule } from '@angular/material/core';
import { PasswordInputComponent } from './components/forms/form-elements/wrapper-second-container/password-input/password-input.component';
import { FirstLayoutComponent } from './components/forms/form-layout/first-layout/first-layout.component';
import { MessageDeliveryComponent } from './components/forms/form-layout/message-delivery/message-delivery.component';
import { PasswordCheckComponent } from './components/forms/form-elements/wrapper-second-container/password-input/password-check/password-check.component';
import { SecondLayoutComponent } from './components/forms/form-layout/second-layout/second-layout.component';
import { ThirdFormLayoutComponent } from './components/forms/form-layout/third-form-layout/third-form-layout.component';
import { ShippingAddressComponent } from './components/forms/form-layout/third-form-layout/shipping-address/shipping-address.component';
import { BillingInfoComponent } from './components/forms/form-layout/third-form-layout/billing-info/billing-info.component';
import { PaymentConfirmationComponent } from './components/forms/form-layout/third-form-layout/payment-confirmation/payment-confirmation.component';
import { FirstMapStyleComponent } from './components/maps/styled-maps/first-map-style/first-map-style.component';
import { SecondMapStyleComponent } from './components/maps/styled-maps/second-map-style/second-map-style.component';
import { ThirdMapComponent } from './components/maps/styled-maps/third-map/third-map.component';
import { FourthMapStyleComponent } from './components/maps/styled-maps/fourth-map-style/fourth-map-style.component';
import { FifthMapStyleComponent } from './components/maps/styled-maps/fifth-map-style/fifth-map-style.component';
import { SixthMapStyleComponent } from './components/maps/styled-maps/sixth-map-style/sixth-map-style.component';
import { MainMapComponent } from './components/maps/styled-maps/main-map/main-map.component';
import { StyledMapsComponent } from './components/maps/styled-maps/styled-maps.component';
import { BasicMapsComponent } from './components/maps/basic-maps/basic-maps.component';
import { StandardMapComponent } from './components/maps/basic-maps/standard-map/standard-map.component';
import { StandardWithMarkerComponent } from './components/maps/basic-maps/standard-with-marker/standard-with-marker.component';
import { StandardAnimatedMarkerComponent } from './components/maps/basic-maps/standard-animated-marker/standard-animated-marker.component';
import { StandardStyledMarkerComponent } from './components/maps/basic-maps/standard-styled-marker/standard-styled-marker.component';
import { MaterialDesignComponent } from './components/icons/material-design/material-design.component';
import { PopularIconsComponent } from './components/icons/material-design/popular-icons/popular-icons.component';
import { BasicIconsComponent } from './components/icons/material-design/basic-icons/basic-icons.component';
import { FontAwesomeComponent } from './components/icons/font-awesome/font-awesome.component';
import { PopularFontAwesomeComponent } from './components/icons/font-awesome/popular-font-awesome/popular-font-awesome.component';
import { BasicFontAwesomeComponent } from './components/icons/font-awesome/basic-font-awesome/basic-font-awesome.component';
import { AlertDownloadCsvComponent } from './components/dashboard/alert-download-csv/alert-download-csv.component';
import { ButtonsComponent } from './components/ui-elements/buttons/buttons.component';
import { RoundedButtonsComponent } from './components/ui-elements/buttons/rounded-buttons/rounded-buttons.component';
import { SquareButtonsComponent } from './components/ui-elements/buttons/square-buttons/square-buttons.component';
import { IconButtonsComponent } from './components/ui-elements/buttons/icon-buttons/icon-buttons.component';
import { ButtonSizesComponent } from './components/ui-elements/buttons/button-sizes/button-sizes.component';
import { ButtonGradientsComponent } from './components/ui-elements/buttons/button-gradients/button-gradients.component';
import { StyledIconButtonsComponent } from './components/ui-elements/buttons/styled-icon-buttons/styled-icon-buttons.component';
import { OutlinedButtonsComponent } from './components/ui-elements/buttons/outlined-buttons/outlined-buttons.component';
import { ColorsComponent } from './components/ui-elements/colors/colors.component';
import { ImagesComponent } from './components/ui-elements/images/images.component';
import { HoverImagesComponent } from './components/ui-elements/images/hover-images/hover-images.component';
import { LoadersComponent } from './components/ui-elements/loaders/loaders.component';
import { AnimatedLoadersComponent } from './components/ui-elements/loaders/animated-loaders/animated-loaders.component';
import { LoadersSizeComponent } from './components/ui-elements/loaders/loaders-size/loaders-size.component';
import { BootstrapButtonsComponent } from './components/ui-elements/buttons/bootstrap-buttons/bootstrap-buttons.component';
import { DefaultLoadersComponent } from './components/ui-elements/loaders/default-loaders/default-loaders.component';
import { BadgesComponent } from './components/ui-elements/badges/badges.component';
import { TextBadgesComponent } from './components/ui-elements/badges/text-badges/text-badges.component';
import { NotificationBadgesComponent } from './components/ui-elements/badges/notification-badges/notification-badges.component';
import { ButtonBadgesComponent } from './components/ui-elements/badges/button-badges/button-badges.component';
import { BadgeSizingComponent } from './components/ui-elements/badges/badge-sizing/badge-sizing.component';
import { PillBadgesComponent } from './components/ui-elements/badges/pill-badges/pill-badges.component';
import { SquareBadgesComponent } from './components/ui-elements/badges/square-badges/square-badges.component';
import { GradientBadgesComponent } from './components/ui-elements/badges/gradient-badges/gradient-badges.component';
import { BadgeInsideComponent } from './components/ui-elements/badges/badge-inside/badge-inside.component';
import { AnimatedBadgeComponent } from './components/ui-elements/badges/animated-badge/animated-badge.component';
import { ButtonLoadersComponent } from './components/ui-elements/loaders/button-loaders/button-loaders.component';
import { GrowingLoadersComponent } from './components/ui-elements/loaders/growing-loaders/growing-loaders.component';
import { TabsComponent } from './components/ui-elements/tabs/tabs.component';
import { BasicTabsComponent } from './components/ui-elements/tabs/basic-tabs/basic-tabs.component';
import { TablesComponent } from './components/tables/tables.component';
import { BasicTableComponent } from './components/tables/basic-table/basic-table.component';
import { TablePaginationComponent } from './components/tables/table-pagination/table-pagination.component';
import { TableSortComponent } from './components/tables/table-sort/table-sort.component';
import { NotiTriggerComponent } from './contains/long-bar/noti-trigger/noti-trigger.component';
import { FilterTableComponent } from './components/tables/filter-table/filter-table.component';
import { SlowAnimationTabsComponent } from './components/ui-elements/tabs/slow-animation-tabs/slow-animation-tabs.component';
import { SlidersComponent } from './components/ui-elements/sliders/sliders.component';
import { BasicSlidersComponent } from './components/ui-elements/sliders/basic-sliders/basic-sliders.component';
import { CustomThumbLabelFormattingComponent } from './components/ui-elements/sliders/custom-thumb-label-formatting/custom-thumb-label-formatting.component';
import { SlidesComponent } from './components/ui-elements/slides/slides.component';
import { ToggleSlidesComponent } from './components/ui-elements/slides/toggle-slides/toggle-slides.component';
import { TwoValuesSliderComponent } from './components/ui-elements/sliders/two-values-slider/two-values-slider.component';
import { BasicSlidesComponent } from './components/ui-elements/slides/basic-slides/basic-slides.component';
import { TwoValueSlidesComponent } from './components/ui-elements/slides/two-value-slides/two-value-slides.component';
import { TextInsideSlideComponent } from './components/ui-elements/slides/text-inside-slide/text-inside-slide.component';
import { SlideWithIconComponent } from './components/ui-elements/slides/slide-with-icon/slide-with-icon.component';
import { GradientSlidesComponent } from './components/ui-elements/slides/gradient-slides/gradient-slides.component';
import { InvertedBasicSlidersComponent } from './components/ui-elements/sliders/inverted-basic-sliders/inverted-basic-sliders.component';
import { VerticalSlidersComponent } from './components/ui-elements/sliders/vertical-sliders/vertical-sliders.component';
import { BasicSlidersWhiteBorderComponent } from './components/ui-elements/sliders/basic-sliders-white-border/basic-sliders-white-border.component';
import { ThumbLabelWhiteBorderComponent } from './components/ui-elements/sliders/thumb-label-white-border/thumb-label-white-border.component';
import { VerticalSliderWhiteBorderComponent } from './components/ui-elements/sliders/vertical-slider-white-border/vertical-slider-white-border.component';
import { LoadersWithTextComponent } from './components/ui-elements/loaders/loaders-with-text/loaders-with-text.component';
import { ProgressBarsComponent } from './components/ui-elements/progress-bars/progress-bars.component';
import { ProgressBarsHeightComponent } from './components/ui-elements/progress-bars/progress-bars-height/progress-bars-height.component';
import { BasicProgressBarsComponent } from './components/ui-elements/progress-bars/basic-progress-bars/basic-progress-bars.component';
import { IndeterminateProgressBarsComponent } from './components/ui-elements/progress-bars/indeterminate-progress-bars/indeterminate-progress-bars.component';
import { QueryProgressBarsComponent } from './components/ui-elements/progress-bars/query-progress-bars/query-progress-bars.component';
import { BufferBarComponent } from './components/ui-elements/progress-bars/buffer-bar/buffer-bar.component';
import { BufferWithValueComponent } from './components/ui-elements/progress-bars/buffer-with-value/buffer-with-value.component';
import { BootstrapProgressBarComponent } from './components/ui-elements/progress-bars/bootstrap-progress-bar/bootstrap-progress-bar.component';
import { StrippedProgressBarComponent } from './components/ui-elements/progress-bars/stripped-progress-bar/stripped-progress-bar.component';
import { ExpansionPanelDataComponent } from './components/ui-elements/expansion-panel/expansion-panel-data/expansion-panel-data.component';
import { ExpansionPanelAnswersComponent } from './components/ui-elements/expansion-panel/expansion-panel-answers/expansion-panel-answers.component';
import { ExpansionPanelAsAccordeonComponent } from './components/ui-elements/expansion-panel/expansion-panel-as-accordeon/expansion-panel-as-accordeon.component';
import { StepperComponent } from './components/stepper/stepper.component';
import { VerticalStepperComponent } from './components/stepper/vertical-stepper/vertical-stepper.component';
import { HorizontalStepperComponent } from './components/stepper/horizontal-stepper/horizontal-stepper.component';
import { KeyframesIndicatorsComponent } from './components/dashboard/keyframes-indicators/keyframes-indicators.component';
import { ChartsComponent } from './components/charts/charts.component';
import { BasicChartsComponent } from './components/charts/basic-charts/basic-charts.component';
import { DoubleCurveChartComponent } from './components/charts/double-curve-chart/double-curve-chart.component';
import { SimpleColumnChartComponent } from './components/charts/simple-column-chart/simple-column-chart.component';
import { HorizontalColumnChartComponent } from './components/charts/horizontal-column-chart/horizontal-column-chart.component';
import { ChartsWithBackgroundComponent } from './components/charts/charts-with-background/charts-with-background.component';
import { TriangleChartComponent } from './components/charts/triangle-chart/triangle-chart.component';
import { LinearChartComponent } from './components/charts/linear-chart/linear-chart.component';
import { BubbleChartComponent } from './components/charts/bubble-chart/bubble-chart.component';
import { SimpleLineChartComponent } from './components/charts/simple-line-chart/simple-line-chart.component';
import { MixedDatasetChartComponent } from './components/charts/mixed-dataset-chart/mixed-dataset-chart.component';
import { RevenueComponent } from './components/dashboard/revenue/revenue.component';
import { DialogComponent } from './components/ui-elements/dialog/dialog.component';
import { DialogScrollableContentComponent, DialogContentExampleDialog } from './components/ui-elements/dialog/dialog-scrollable-content/dialog-scrollable-content.component';
import { InteractiveDialogComponent, InteractiveDialogContent } from './components/ui-elements/dialog/interactive-dialog/interactive-dialog.component';
import { DisableCloseDialogComponent, DisableCloseDialogContent } from './components/ui-elements/dialog/disable-close-dialog/disable-close-dialog.component';
import { CommonModule } from '@angular/common';
import { InputsComponent } from './components/forms/form-elements/inputs/inputs.component';
import { PicklistFieldComponent } from './components/forms/form-elements/picklist-field/picklist-field.component';
import { RadioButtonsComponent } from './components/forms/form-elements/radio-buttons/radio-buttons.component';
import { ButtonToggleFormComponent } from './components/forms/form-elements/button-toggle-form/button-toggle-form.component';
import { ButtonToggleFormTextComponent } from './components/forms/form-elements/button-toggle-form-text/button-toggle-form-text.component';
import { ErrorPageStyleOneComponent } from './components/error-pages/error-page-style-one/error-page-style-one.component';
import { ErrorPageStyleTwoComponent } from './components/error-pages/error-page-style-two/error-page-style-two.component';
import { ErrorPageStyleThreeComponent } from './components/error-pages/error-page-style-three/error-page-style-three.component';
import { AppProviderService} from'./services/appprovider.service';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { PriceListComponent } from './components/price-list/price-list.component';
import { PriceListIconsComponent } from './components/price-list/price-list-icons/price-list-icons.component';
import { PriceListRocketComponent } from './components/price-list/price-list-rocket/price-list-rocket.component';
import { LoginMainPageComponent } from './components/pages/login-modals/login-main-page/login-main-page.component';
import { LoginPageTwoComponent } from './components/pages/login-modals/login-page-two/login-page-two.component';
import { LoginPageThreeComponent } from './components/pages/login-modals/login-page-three/login-page-three.component';
import { CalendarComponent } from './components/calendar/calendar.component';
import { MyWalletComponent } from './components/my-wallet/my-wallet.component';
import { MyBalanceComponent } from './components/my-wallet/my-balance/my-balance.component';
import { PaymentHistoryComponent } from './components/my-wallet/payment-history/payment-history.component';
import { PriceChartComponent } from './components/my-wallet/price-chart/price-chart.component';
import { SubscribersComponent } from './components/subscribers/subscribers.component';
import { SubscribersTabelComponent } from './components/subscribers/subscribers-tabel/subscribers-tabel.component';
import { SubscribersChartComponent } from './components/subscribers/subscribers-chart/subscribers-chart.component';
import { StrokedButtonComponent } from './components/ui-elements/buttons/stroked-button/stroked-button.component';
import { FabButtonsComponent } from './components/ui-elements/buttons/fab-buttons/fab-buttons.component';
import { LabelAlignmentRightComponent } from './components/ui-elements/tabs/label-alignment-right/label-alignment-right.component';
import { LabelAlignmentCenterComponent } from './components/ui-elements/tabs/label-alignment-center/label-alignment-center.component';
import { FormDialogComponent, FormDialogContent } from './components/ui-elements/dialog/form-dialog/form-dialog.component';
import { DeadlinesChartComponent } from './components/charts/deadlines-chart/deadlines-chart.component';
import { NotificationsComponent } from './components/ui-elements/notifications/notifications.component';
import { TriggerNotificationsComponent } from './components/trigger-notifications/trigger-notifications.component';
import { LeftNotificationsComponent } from './components/trigger-notifications/left-notifications/left-notifications.component';
import { AppPublicNotifications } from './services/public-noti.service';
import { CardService } from './services/card.service';
import { CardsComponent, AddCardComponent } from './components/my-wallet/cards/cards.component';
import { CreditCardDirective } from './directive/credit-card.directive';
import { ValidatorComponent } from './shared/validator/validator.component';
import { SvgIconsComponent } from './shared/svg-icons/svg-icons.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}


@NgModule({
  declarations: [
    routingComponents,
    AppComponent,
    LogoutModal,
    CreditCardDirective,
    InteractiveDialogContent,
    ExpansionPanelDataComponent,
    SidebarComponent,
    DashboardComponent,
    FstCardComponent,
    InvoicesComponent,
    WeatherComponent,
    DataTableComponent,
    DiagramPriceComponent,
    DiagramDailySalesComponent,
    DiagramCompletedTasksComponent,
    DiagramTotalShipmentsComponent,
    EarningsComponent,
    CurrentBalanceComponent,
    WithdrawMoneyComponent,
    SelectAmountComponent,
    ConfirmationNumberComponent,
    AppRoutingComponent,
    AboutCompanyComponent,
    TotalVisitorsComponent,
    TotalClicksComponent,
    TotalItemsComponent,
    TasksDoneComponent,
    RecentActivityComponent,
    FormElementsComponent,
    FormLayoutComponent,
    FormStyleOneComponent,
    FormStyleTwoComponent,
    AddCardComponent,
    TextAreaComponent,
    Settings,
    CheckboxesComponent,
    TextAreaStyleOneComponent,
    TextAreaStyleTwoComponent,
    TextAreaStyleThreeComponent,
    SmallTextAreaComponent,
    MediumTextAreaComponent,
    LargeTextAreaComponent,
    TextAreaFocusOneComponent,
    TextAreaFocusTwoComponent,
    TextAreaDottedOneComponent,
    TextAreaDottedTwoComponent,
    TextAreaDottedThreeComponent,
    WrapperContainerComponent,
    FileBrowserComponent,
    FileBrowserStyleTwoComponent,
    FileBrowserStyleOneComponent,
    FirstCheckboxComponent,
    SecondCheckboxComponent,
    ThirdCheckboxComponent,
    FourthCheckboxComponent,
    FifthCheckboxComponent,
    WrapperSecondContainerComponent,
    SubmitButtonComponent,
    DatePickerComponent,
    PasswordInputComponent,
    FirstLayoutComponent,
    MessageDeliveryComponent,
    PasswordCheckComponent,
    SecondLayoutComponent,
    ThirdFormLayoutComponent,
    ShippingAddressComponent,
    BillingInfoComponent,
    PaymentConfirmationComponent,
    FirstMapStyleComponent,
    SecondMapStyleComponent,
    ThirdMapComponent,
    FourthMapStyleComponent,
    FifthMapStyleComponent,
    SixthMapStyleComponent,
    MainMapComponent,
    StyledMapsComponent,
    BasicMapsComponent,
    StandardMapComponent,
    StandardWithMarkerComponent,
    StandardAnimatedMarkerComponent,
    StandardStyledMarkerComponent,
    MaterialDesignComponent,
    PopularIconsComponent,
    BasicIconsComponent,
    FontAwesomeComponent,
    PopularFontAwesomeComponent,
    BasicFontAwesomeComponent,
    AlertDownloadCsvComponent,
    ButtonsComponent,
    RoundedButtonsComponent,
    SquareButtonsComponent,
    IconButtonsComponent,
    ButtonSizesComponent,
    ButtonGradientsComponent,
    StyledIconButtonsComponent,
    OutlinedButtonsComponent,
    ColorsComponent,
    ImagesComponent,
    HoverImagesComponent,
    LoadersComponent,
    ValidatorComponent,
    AnimatedLoadersComponent,
    LoadersSizeComponent,
    BootstrapButtonsComponent,
    DefaultLoadersComponent,
    BadgesComponent,
    TextBadgesComponent,
    NotificationBadgesComponent,
    ButtonBadgesComponent,
    BadgeSizingComponent,
    PillBadgesComponent,
    SquareBadgesComponent,
    GradientBadgesComponent,
    BadgeInsideComponent,
    AnimatedBadgeComponent,
    ButtonLoadersComponent,
    GrowingLoadersComponent,
    TabsComponent,
    BasicTabsComponent,
    DisableCloseDialogContent,
    TablesComponent,
    BasicTableComponent,
    TablePaginationComponent,
    TableSortComponent,
    NotiTriggerComponent,
    FilterTableComponent,
    SlowAnimationTabsComponent,
    SlidersComponent,
    BasicSlidersComponent,
    CustomThumbLabelFormattingComponent,
    SlidesComponent,
    ToggleSlidesComponent,
    TwoValuesSliderComponent,
    BasicSlidesComponent,
    TwoValueSlidesComponent,
    TextInsideSlideComponent,
    SlideWithIconComponent,
    GradientSlidesComponent,
    InvertedBasicSlidersComponent,
    VerticalSlidersComponent,
    BasicSlidersWhiteBorderComponent,
    ThumbLabelWhiteBorderComponent,
    VerticalSliderWhiteBorderComponent,
    LoadersWithTextComponent,
    ProgressBarsComponent,
    ProgressBarsHeightComponent,
    BasicProgressBarsComponent,
    IndeterminateProgressBarsComponent,
    QueryProgressBarsComponent,
    BufferBarComponent,
    BufferWithValueComponent,
    BootstrapProgressBarComponent,
    StrippedProgressBarComponent,
    ExpansionPanelAnswersComponent,
    ExpansionPanelAsAccordeonComponent,
    StepperComponent,
    VerticalStepperComponent,
    HorizontalStepperComponent,
    KeyframesIndicatorsComponent,
    ChartsComponent,
    BasicChartsComponent,
    DoubleCurveChartComponent,
    SimpleColumnChartComponent,
    HorizontalColumnChartComponent,
    ChartsWithBackgroundComponent,
    TriangleChartComponent,
    LinearChartComponent,
    BubbleChartComponent,
    SimpleLineChartComponent,
    DialogContentExampleDialog,
    MixedDatasetChartComponent,
    RevenueComponent,
    DialogComponent,
    DialogScrollableContentComponent,
    InteractiveDialogComponent,
    DisableCloseDialogComponent,
    InputsComponent,
    PicklistFieldComponent,
    RadioButtonsComponent,
    ButtonToggleFormComponent,
    ButtonToggleFormTextComponent,
    ErrorPageStyleOneComponent,
    LongBarComponent,
    ErrorPageStyleTwoComponent,
    ErrorPageStyleThreeComponent,
    PriceListComponent,
    PriceListIconsComponent,
    PriceListRocketComponent,
    LoginMainPageComponent,
    LoginPageTwoComponent,
    LoginPageThreeComponent,
    FormDialogContent,
    CalendarComponent,
    MyWalletComponent,
    MyBalanceComponent,
    PaymentHistoryComponent,
    PriceChartComponent,
    SubscribersComponent,
    SubscribersTabelComponent,
    SubscribersChartComponent,
    StrokedButtonComponent,
    FabButtonsComponent,
    LabelAlignmentRightComponent,
    LabelAlignmentCenterComponent,
    FormDialogComponent,
    DeadlinesChartComponent,
    NotificationsComponent,
    TriggerNotificationsComponent,
    LeftNotificationsComponent,
    CardsComponent,
    SvgIconsComponent,
  ],
  imports: [
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    FlatpickrModule.forRoot(),
    MatButtonToggleModule,
    GoogleMapsModule,
    MatBadgeModule,
    CommonModule,
    MatRippleModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    GoogleChartsModule,
    FormsModule , 
    MatListModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatSliderModule,
    BrowserAnimationsModule,
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    MatDialogModule,
    HttpClientModule,
    MatExpansionModule,
    MatSortModule,
    MatSortModule,
    HttpClientJsonpModule,
    MatTableModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatMenuModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule,
    FontAwesomeModule,
    MatButtonModule,
    MatTooltipModule,
    MatRadioModule,
    FullCalendarModule,
    MatProgressBarModule,
    MatStepperModule,
    MatCheckboxModule,
    HttpClientModule,
    MatIconModule,
    MatSelectModule,
    MatChipsModule,
    MatCardModule,
    MatTabsModule,
    NgbModalModule ,
    MatSlideToggleModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    AppProviderService,
    CardService,
    AppPublicNotifications
  ],
  bootstrap: [AppComponent],
  
})

export class AppModule { 

}

